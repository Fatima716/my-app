/* ============================================================
   app.js — التشغيل: التنقل، الإعدادات، ربط الأزرار
   لإضافة قسم جديد: أنشئي ملفاً مثل habits.js وأضيفيه في MODS
   ============================================================ */

const App = (() => {
  const MODS = [
    { id: 'tasks',   label: 'المهام',   icon: '✅', mod: Tasks },
    { id: 'money',   label: 'المصاريف', icon: '💰', mod: Money },
    { id: 'habits',  label: 'العادات',  icon: '🌱', mod: Habits },
    { id: 'outfits', label: 'الملابس',  icon: '👗', mod: Outfits }
  ];
  let tab = 'tasks';
  try { tab = localStorage.getItem('myapp.tab') || 'tasks'; } catch (e) {}
  if (!MODS.some(m => m.id === tab)) tab = 'tasks';

  function render() {
    const cur = MODS.find(m => m.id === tab);
    const view = $('#view'), top = view.scrollTop;

    // تذكير بالنسخ الاحتياطي إذا مضى أسبوع
    const days = Backup.daysSince();
    const stale = Store.hasData() && (days === null || days >= 7);
    const banner = stale ? `<div class="banner">${days === null ? 'لم تأخذي نسخة احتياطية بعد.' : 'مضى ' + days + ' يوماً على آخر نسخة احتياطية.'}
      <button class="btn sm" style="margin-top:8px" data-act="backup">خذي نسخة الآن</button></div>` : '';

    view.innerHTML = banner + cur.mod.render();
    view.scrollTop = top;
    $('#title').textContent = cur.mod.title;
    $('#nav').innerHTML = MODS.map(m =>
      `<button class="${m.id === tab ? 'on' : ''}" data-act="tab" data-v="${m.id}"><span>${m.icon}</span>${m.label}</button>`).join('');
  }

  function settings() {
    const d = Backup.daysSince();
    UI.sheet(`<h2>الإعدادات</h2>
      <label>رمز العملة<input id="s_cur" value="${UI.esc(Store.d.meta.currency)}"></label>
      <button class="btn ghost" data-act="saveCur">حفظ العملة</button>
      <h2 style="margin-top:22px">النسخ الاحتياطي</h2>
      <p class="muted">آخر نسخة: ${d === null ? 'لا يوجد' : d === 0 ? 'اليوم' : 'قبل ' + d + ' يوم'}.<br>
      عند الضغط تظهر قائمة المشاركة، اختاري <b>Drive</b> لحفظ الملف في حسابك على Google.</p>
      <button class="btn" data-act="backup">📤 إنشاء نسخة احتياطية</button>
      <label style="margin-top:14px">📥 استعادة من نسخة (ملف .json)
        <input type="file" accept=".json,application/json" data-chg="restoreFile"></label>`);
  }

  Actions.tab = el => { tab = el.dataset.v; try { localStorage.setItem('myapp.tab', tab); } catch (e) {} render(); };
  Actions.fab = () => MODS.find(m => m.id === tab).mod.add();
  Actions.settings = settings;
  Actions.backup = () => Backup.export().then(render);
  Actions.restoreFile = el => { if (el.files[0]) Backup.restore(el.files[0]); };
  Actions.saveCur = () => {
    Store.d.meta.currency = $('#s_cur').value.trim() || 'د.ل';
    Store.save(); UI.close(); render();
  };

  // زر + ثابت
  const fab = document.createElement('button');
  fab.className = 'fab'; fab.dataset.act = 'fab'; fab.textContent = '+'; fab.setAttribute('aria-label', 'إضافة');
  document.body.appendChild(fab);

  // ربط كل الأزرار بدالة واحدة (event delegation)
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (el && Actions[el.dataset.act]) Actions[el.dataset.act](el, e);
  });
  document.addEventListener('change', e => {
    const el = e.target.closest('[data-chg]');
    if (el && Actions[el.dataset.chg]) Actions[el.dataset.chg](el, e);
  });

  Photos.init().then(render);
  render();
  return { render };
})();
