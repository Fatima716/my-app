/* ============================================================
   app.js — التشغيل: التنقل، الإعدادات، ربط الأزرار
   لإضافة قسم جديد: أنشئي ملفاً مثل tasks.js وأضيفيه في MODS
   ============================================================ */

const App = (() => {
  const MODS = [
    { id: 'tasks',   label: 'المهام',   icon: '✅', mod: Tasks },
    { id: 'money',   label: 'المال', icon: '💰', mod: Money },
    { id: 'outfits', label: 'الملابس',  icon: '👗', mod: Outfits }
  ];
  let tab = 'tasks';
  try { tab = localStorage.getItem('myapp.tab') || 'tasks'; } catch (e) {}
  if (!MODS.some(m => m.id === tab)) tab = 'tasks';

  function render() {
    const cur = MODS.find(m => m.id === tab);
    const view = $('#view'), top = view.scrollTop;

    // تذكير بالنسخ الاحتياطي إذا مضى أسبوع
    const days = Backup.daysSince();
    const stale = Store.hasData() && (days === null || days >= 7);
    const banner = stale ? `<div class="banner">${days === null ? 'لم تأخذي نسخة احتياطية بعد.' : 'مضى ' + days + ' يوماً على آخر نسخة احتياطية.'}
      <button class="btn sm" style="margin-top:8px" data-act="backup">خذي نسخة الآن</button></div>` : '';

    view.innerHTML = banner + cur.mod.render();
    view.scrollTop = top;
    $('#title').textContent = cur.mod.title;
    $('#nav').innerHTML = MODS.map(m =>
      `<button class="${m.id === tab ? 'on' : ''}" data-act="tab" data-v="${m.id}"><span>${m.icon}</span>${m.label}</button>`).join('');
  }

  function settings() {
    const d = Backup.daysSince();
    UI.sheet(`<h2>الإعدادات</h2>
      <h2 style="font-size:16px;margin-top:4px">☁️ حسابك والمزامنة</h2>
      ${Sync.settingsHtml()}
      <h2 style="font-size:16px;margin-top:22px">العملة</h2>
      <label>رمز العملة<input id="s_cur" value="${UI.esc(Store.d.meta.currency)}"></label>
      <button class="btn ghost" data-act="saveCur">حفظ العملة</button>
      <h2 style="font-size:16px;margin-top:22px">النسخ الاحتياطي بملف</h2>
      <p class="muted">آخر نسخة: ${d === null ? 'لا يوجد' : d === 0 ? 'اليوم' : 'قبل ' + d + ' يوم'}.<br>
      عند الضغط تظهر قائمة المشاركة، اختاري <b>Drive</b> لحفظ الملف في حسابك على Google.</p>
      <button class="btn" data-act="backup">📤 إنشاء نسخة احتياطية</button>
      <button class="btn ghost" style="margin-top:14px" data-act="restorePick">📥 استعادة من نسخة (ملف .json)</button>
      <details style="margin-top:10px"><summary class="muted">طريقة بديلة للاستعادة</summary>
        <label>اختيار الملف<input type="file" id="s_file"></label></details>`);
    const fi = document.getElementById('s_file');
    if (fi) ['change', 'input'].forEach(ev => fi.addEventListener(ev, () => {
      const f = fi.files && fi.files[0];
      if (f) { UI.toast('تم اختيار الملف'); Backup.restore(f); }
    }));
  }

  Actions.tab = el => { tab = el.dataset.v; try { localStorage.setItem('myapp.tab', tab); } catch (e) {} render(); };
  Actions.fab = () => MODS.find(m => m.id === tab).mod.add();
  Actions.settings = settings;
  Actions.backup = () => Backup.export().then(render);
  Actions.restorePick = async () => {
    const FP = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.FilePicker;
    if (!FP) { UI.toast('استخدمي «الطريقة البديلة» أسفل الزر'); return; }
    try {
      const r = await FP.pickFiles({ limit: 1, readData: true });
      const f = r && r.files && r.files[0];
      if (!f) return;
      UI.toast('تم اختيار الملف: ' + (f.name || ''));
      let blob = f.blob;
      if (!blob && f.data) {
        const bin = atob(f.data), u = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        blob = new Blob([u], { type: 'application/json' });
      }
      if (!blob && f.path && window.Capacitor.convertFileSrc) blob = await (await fetch(window.Capacitor.convertFileSrc(f.path))).blob();
      if (!blob) throw new Error('لم يُقرأ محتوى الملف');
      await Backup.restore(blob);
    } catch (e) {
      if (!/cancel/i.test(String(e && e.message))) UI.toast('تعذر اختيار الملف: ' + (e && e.message || e));
    }
  };
  Actions.restoreFile = el => { const f = el.files[0]; if (f) Backup.restore(f).then(() => { try { el.value = ''; } catch (e) {} }); };
  Actions.saveCur = () => {
    Store.d.meta.currency = $('#s_cur').value.trim() || 'د.ل';
    Store.save(); UI.close(); render();
  };

  // زر + ثابت
  const fab = document.createElement('button');
  fab.className = 'fab'; fab.dataset.act = 'fab'; fab.textContent = '+'; fab.setAttribute('aria-label', 'إضافة');
  document.body.appendChild(fab);

  // ربط كل الأزرار بدالة واحدة (event delegation)
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (el && Actions[el.dataset.act]) Actions[el.dataset.act](el, e);
  });
  document.addEventListener('change', e => {
    const el = e.target.closest('[data-chg]');
    if (el && Actions[el.dataset.chg]) Actions[el.dataset.chg](el, e);
  });

  Photos.init().then(() => { render(); Sync.init(); });
  render();
  return { render, settings };
})();
