/* ============================================================
   cutout.js — معالجة الصور داخل الجوال (بدون إنترنت):
   1) تحديد لون القطعة تلقائياً
   2) إزالة الخلفية (تعمل جيداً مع خلفية موحدة: جدار، أرضية، سرير...)
   ============================================================ */

const Cut = (() => {

  /* ---------- أسماء الألوان (تطابق قائمة الألوان في قسم الملابس) ---------- */
  function nameOf(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    const l = (max + min) / 2;
    const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    let h = 0;
    if (d !== 0) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    if (l < 0.13) return 'أسود';
    if (l > 0.92 && s < 0.5) return 'أبيض';
    if (s < 0.14) return l > 0.82 ? 'أبيض' : l < 0.2 ? 'أسود' : 'رمادي';
    // أحمر / وردي
    if (h >= 340 || h < 8) return l > 0.76 ? 'وردي' : 'أحمر';
    if (h >= 318 && h < 340) return l > 0.45 ? 'وردي' : 'أحمر';
    // برتقالي / بني / بيج
    if (h >= 8 && h < 45) {
      if (l < 0.36) return 'بني';
      if (s < 0.5) return l > 0.55 ? 'بيج' : 'بني';
      if (h < 24 && l > 0.7) return 'وردي';
      return l > 0.42 ? 'برتقالي' : 'بني';
    }
    if (h >= 45 && h < 68) {
      if (l < 0.3) return 'بني';
      return (s < 0.4 && l > 0.6) ? 'بيج' : 'أصفر';
    }
    if (h >= 68 && h < 168) return 'أخضر';
    if (h >= 168 && h < 188) return l < 0.3 ? 'كحلي' : 'أخضر';
    if (h >= 188 && h < 252) return l < 0.3 ? 'كحلي' : 'أزرق';
    return 'بنفسجي';   // 252 – 318
  }

  const dist = (r1, g1, b1, r2, g2, b2) => Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);

  function smallData(canvas, max) {
    const s = Math.min(1, max / Math.max(canvas.width, canvas.height));
    const w = Math.max(1, Math.round(canvas.width * s)), h = Math.max(1, Math.round(canvas.height * s));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(canvas, 0, 0, w, h);
    return { w, h, data: x.getImageData(0, 0, w, h).data };
  }

  const median = arr => { arr.sort((a, b) => a - b); return arr[arr.length >> 1]; };

  // يقدّر لون خلفية الصورة من إطارها الخارجي
  function borderColor(data, w, h, ring) {
    const R = [], G = [], B = [];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (x >= ring && x < w - ring && y >= ring && y < h - ring) { x = w - ring - 1; continue; }
      const i = (y * w + x) * 4; R.push(data[i]); G.push(data[i + 1]); B.push(data[i + 2]);
    }
    return [median(R), median(G), median(B)];
  }

  /* ---------- لون القطعة الغالب ---------- */
  function dominantColor(canvas) {
    const { w, h, data } = smallData(canvas, 64);
    let hasAlpha = false;
    for (let i = 3; i < data.length; i += 4) if (data[i] < 200) { hasAlpha = true; break; }
    const bg = hasAlpha ? null : borderColor(data, w, h, 2);

    const collect = onlyDifferent => {
      const votes = {}; let n = 0;
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if (data[i + 3] < 200) continue;
        if (!hasAlpha) {                                   // نركّز على وسط الصورة
          if (x < w * 0.12 || x > w * 0.88 || y < h * 0.08 || y > h * 0.92) continue;
          if (onlyDifferent && dist(data[i], data[i + 1], data[i + 2], bg[0], bg[1], bg[2]) < 42) continue;
        }
        const nm = nameOf(data[i], data[i + 1], data[i + 2]);
        votes[nm] = (votes[nm] || 0) + 1; n++;
      }
      return { votes, n };
    };
    let r = collect(!hasAlpha);
    if (!hasAlpha && r.n < w * h * 0.04) r = collect(false);   // قطعة بلون الخلفية نفسها
    let best = null;
    for (const k in r.votes) if (best === null || r.votes[k] > r.votes[best]) best = k;
    return best || 'أسود';
  }

  /* ---------- إزالة الخلفية ----------
     strength: 0..100 (الأعلى = يزيل ألواناً أقرب للخلفية).
     يرجع {canvas} أو {error}                                   */
  function removeBackground(srcCanvas, strength = 35) {
    const MAX = 560;
    const s = Math.min(1, MAX / Math.max(srcCanvas.width, srcCanvas.height));
    const w = Math.max(1, Math.round(srcCanvas.width * s)), h = Math.max(1, Math.round(srcCanvas.height * s));
    const work = document.createElement('canvas'); work.width = w; work.height = h;
    const ctx = work.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(srcCanvas, 0, 0, w, h);
    const img = ctx.getImageData(0, 0, w, h), d = img.data;

    const tol = 12 + strength * 0.8;                       // 12 .. 92
    const bg = borderColor(d, w, h, 3);
    const N = w * h;
    const isBg = new Uint8Array(N);
    const stack = new Int32Array(N);
    let sp = 0;

    const dBg = p => dist(d[p * 4], d[p * 4 + 1], d[p * 4 + 2], bg[0], bg[1], bg[2]);
    const dPix = (p, q) => dist(d[p * 4], d[p * 4 + 1], d[p * 4 + 2], d[q * 4], d[q * 4 + 1], d[q * 4 + 2]);

    // نبدأ من حدود الصورة
    const seed = p => { if (!isBg[p] && dBg(p) <= tol) { isBg[p] = 1; stack[sp++] = p; } };
    for (let x = 0; x < w; x++) { seed(x); seed((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { seed(y * w); seed(y * w + w - 1); }

    // نملأ الخلفية: بكسل مجاور يشبه لون الخلفية، أو يشبه جاره (تدرّج إضاءة) وليس بعيداً عنها
    const local = tol * 0.18, far = tol * 1.9;
    while (sp > 0) {
      const p = stack[--sp], x = p % w, y = (p / w) | 0;
      const nb = [x > 0 ? p - 1 : -1, x < w - 1 ? p + 1 : -1, y > 0 ? p - w : -1, y < h - 1 ? p + w : -1];
      for (let k = 0; k < 4; k++) {
        const q = nb[k];
        if (q < 0 || isBg[q]) continue;
        const db = dBg(q);
        if (db <= tol || (db <= far && dPix(p, q) <= local)) { isBg[q] = 1; stack[sp++] = q; }
      }
    }

    // نُبقي أكبر كتلة أمامية فقط (نتخلص من البقع الصغيرة)
    const label = new Int32Array(N);
    let bestLabel = 0, bestSize = 0, cur = 0;
    for (let p0 = 0; p0 < N; p0++) {
      if (isBg[p0] || label[p0]) continue;
      cur++; let size = 0; sp = 0; stack[sp++] = p0; label[p0] = cur;
      while (sp > 0) {
        const p = stack[--sp]; size++;
        const x = p % w, y = (p / w) | 0;
        if (x > 0 && !isBg[p - 1] && !label[p - 1]) { label[p - 1] = cur; stack[sp++] = p - 1; }
        if (x < w - 1 && !isBg[p + 1] && !label[p + 1]) { label[p + 1] = cur; stack[sp++] = p + 1; }
        if (y > 0 && !isBg[p - w] && !label[p - w]) { label[p - w] = cur; stack[sp++] = p - w; }
        if (y < h - 1 && !isBg[p + w] && !label[p + w]) { label[p + w] = cur; stack[sp++] = p + w; }
      }
      if (size > bestSize) { bestSize = size; bestLabel = cur; }
    }
    const frac = bestSize / N;
    if (!bestLabel || frac < 0.03) return { error: 'لم أجد قطعة واضحة. جرّبي رفع القوة أو صورة بخلفية أبسط.' };
    if (frac > 0.97) return { error: 'لم تُزَل الخلفية. جرّبي رفع القوة (الخلفية قريبة من لون القطعة).' };

    // قناع ناعم الحواف
    const m = new Float32Array(N);
    for (let p = 0; p < N; p++) m[p] = label[p] === bestLabel ? 1 : 0;
    const bl = new Float32Array(N);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let sum = 0, cnt = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const xx = x + dx, yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= w || yy >= h) { sum += m[y * w + x]; cnt++; continue; }
        sum += m[yy * w + xx]; cnt++;
      }
      bl[y * w + x] = sum / cnt;
    }
    let minX = w, minY = h, maxX = -1, maxY = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const p = y * w + x;
      const a = Math.max(0, Math.min(1, (bl[p] - 0.4) / 0.4));   // حواف ناعمة قليلاً
      d[p * 4 + 3] = Math.round(a * 255);
      if (d[p * 4 + 3] > 8) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
    }
    ctx.putImageData(img, 0, 0);

    // قص على حدود القطعة مع هامش صغير
    const pad = 4;
    minX = Math.max(0, minX - pad); minY = Math.max(0, minY - pad);
    maxX = Math.min(w - 1, maxX + pad); maxY = Math.min(h - 1, maxY + pad);
    const out = document.createElement('canvas');
    out.width = maxX - minX + 1; out.height = maxY - minY + 1;
    out.getContext('2d').drawImage(work, minX, minY, out.width, out.height, 0, 0, out.width, out.height);
    return { canvas: out };
  }

  // اختصار: من صورة محفوظة (dataURL) إلى لوحة
  async function canvasFromData(dataUrl) {
    const img = await UI.loadImage(dataUrl);
    const c = document.createElement('canvas');
    c.width = img.naturalWidth; c.height = img.naturalHeight;
    c.getContext('2d').drawImage(img, 0, 0);
    return c;
  }

  return { nameOf, dominantColor, removeBackground, canvasFromData };
})();
