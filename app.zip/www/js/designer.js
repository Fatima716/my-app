/* ============================================================
   designer.js — مصمم الإطلالات على لوحة
   - اسحبي القطعة لتحريكها، وبإصبعين: تكبير/تصغير وتدوير
   - أزرار + − ↻ ↺ تعمل دائماً كبديل عن اللمس بإصبعين
   - حفظ في الإطلالات، أو مشاركة/حفظ كصورة
   ============================================================ */

const Designer = (() => {
  const BGS = ['#ffffff', '#fbf3ea', '#f6d9e4', '#e7e0f5', '#dfeee6', '#2b2433'];
  // موضع وحجم أولي لكل نوع (x, y, عرض) كنسب من اللوحة
  const POS = { dress: [.5, .46, .55], top: [.5, .27, .46], bottom: [.5, .62, .42], outer: [.26, .3, .36], shoes: [.5, .88, .3], bag: [.8, .62, .26], acc: [.2, .88, .2] };

  let S = null;              // الحالة: {lookId, items:[{u,itemId,x,y,w,rot}], bg, sel, dirty}
  let pk = null;             // قطع مختارة للإضافة
  const imgs = {};           // صور محمّلة للتصدير
  const ptrs = new Map();
  let g = null;
  let isOpen = false;

  const el = () => $('#designer');
  const stage = () => $('#d-stage');
  const cur = () => S && S.items.find(e => e.u === S.sel);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function srcOf(itemId) {
    const p = Photos.get(itemId);
    if (p) return p;
    const it = Store.d.items.find(i => i.id === itemId) || { cat: 'top', color: '' };
    const c = document.createElement('canvas'); c.width = c.height = 300;
    const x = c.getContext('2d');
    x.fillStyle = (Outfits.COLORS[it.color] || '#d9c3a0') + '55'; x.fillRect(0, 0, 300, 300);
    x.font = '170px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText((Outfits.CATS[it.cat] || ['', '👚'])[1], 150, 160);
    return c.toDataURL('image/png');
  }
  async function getImg(itemId) {
    if (!imgs[itemId] || imgs[itemId].__src !== Photos.get(itemId)) {
      const im = await UI.loadImage(srcOf(itemId)); im.__src = Photos.get(itemId); imgs[itemId] = im;
    }
    return imgs[itemId];
  }

  function autoPlace(itemId, taken) {
    const it = Store.d.items.find(i => i.id === itemId);
    const cat = it ? it.cat : 'top';
    const [x, y, w] = POS[cat] || POS.top;
    const n = taken.filter(t => t === cat).length;       // قطعة ثانية من النوع نفسه: نزيحها
    taken.push(cat);
    return { u: Store.uid(), itemId, x: clamp(x + (n % 2 ? 0.22 : -0.22) * Math.ceil(n / 2), .1, .9), y: clamp(y + n * 0.04, .1, .92), w, rot: 0 };
  }

  function build() {
    el().innerHTML = `
      <div class="d-head"><button class="icon-btn" data-act="dClose" aria-label="إغلاق">✕</button>
        <b>مصمم الإطلالة</b><button class="btn sm" data-act="dSave">حفظ</button></div>
      <div class="d-body"><div id="d-stage" style="background:${S.bg}"></div></div>
      <div class="d-tools">
        <div class="d-row">
          <button data-act="dAdd">＋ قطعة</button><button data-act="dBig">＋</button><button data-act="dSmall">−</button>
          <button data-act="dRotL">↺</button><button data-act="dRotR">↻</button>
          <button data-act="dFront" aria-label="للأمام">⬆</button><button data-act="dBack" aria-label="للخلف">⬇</button>
          <button data-act="dDel" aria-label="حذف">🗑</button></div>
        <div class="d-row sw">${BGS.map(c => `<button class="swatch" data-act="dBg" data-c="${c}" style="background:${c}" aria-label="لون الخلفية"></button>`).join('')}
          <button class="wide" data-act="dShare">📤 مشاركة / حفظ الصورة</button></div>
        <div class="d-hint">اسحبي القطعة لتحريكها · إصبعان للتكبير والتدوير · أو استخدمي الأزرار</div>
      </div>`;
    const st = stage();
    st.addEventListener('pointerdown', down);
    st.addEventListener('pointermove', move);
    st.addEventListener('pointerup', up);
    st.addEventListener('pointercancel', up);
    paintAll();
  }

  function paintAll() {
    const st = stage(); if (!st) return;
    st.style.background = S.bg;
    st.innerHTML = S.items.map(e => `<div class="de" data-u="${e.u}"><img alt="" draggable="false" src="${srcOf(e.itemId).replace(/"/g, '')}"></div>`).join('');
    S.items.forEach(paint);
  }
  function paint(e) {
    const d = stage() && stage().querySelector(`.de[data-u="${e.u}"]`); if (!d) return;
    d.style.left = (e.x * 100) + '%'; d.style.top = (e.y * 100) + '%'; d.style.width = (e.w * 100) + '%';
    d.style.transform = `translate(-50%,-50%) rotate(${e.rot}deg)`;
    d.style.zIndex = S.items.indexOf(e) + 1;
    d.classList.toggle('sel', e.u === S.sel);
  }
  const select = u => { S.sel = u; S.items.forEach(paint); };

  /* ---------- اللمس ---------- */
  function down(ev) {
    const d = ev.target.closest('.de');
    if (ptrs.size === 0) { if (d) select(d.dataset.u); else { select(null); return; } }
    else if (!S.sel) return;
    stage().setPointerCapture(ev.pointerId);
    ptrs.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    startGesture();
  }
  function startGesture() {
    const e = cur(); if (!e) return;
    const pts = [...ptrs.values()], rect = stage().getBoundingClientRect();
    g = { rect, x: e.x, y: e.y, w: e.w, rot: e.rot };
    if (pts.length === 1) g.p0 = pts[0];
    else {
      const [a, b] = pts;
      g.d0 = Math.max(1, Math.hypot(b.x - a.x, b.y - a.y)); g.a0 = Math.atan2(b.y - a.y, b.x - a.x);
      g.c0 = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    }
  }
  function move(ev) {
    if (!ptrs.has(ev.pointerId)) return;
    ptrs.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    const e = cur(); if (!e || !g) return;
    const pts = [...ptrs.values()];
    if (pts.length === 1) {
      e.x = clamp(g.x + (pts[0].x - g.p0.x) / g.rect.width, -.1, 1.1);
      e.y = clamp(g.y + (pts[0].y - g.p0.y) / g.rect.height, -.1, 1.1);
    } else {
      const [a, b] = pts, d = Math.hypot(b.x - a.x, b.y - a.y), ang = Math.atan2(b.y - a.y, b.x - a.x);
      e.w = clamp(g.w * d / g.d0, .06, 1.5);
      e.rot = g.rot + (ang - g.a0) * 180 / Math.PI;
      e.x = clamp(g.x + ((a.x + b.x) / 2 - g.c0.x) / g.rect.width, -.1, 1.1);
      e.y = clamp(g.y + ((a.y + b.y) / 2 - g.c0.y) / g.rect.height, -.1, 1.1);
    }
    S.dirty = true; paint(e);
  }
  function up(ev) {
    ptrs.delete(ev.pointerId);
    if (ptrs.size > 0) startGesture(); else g = null;
  }

  /* ---------- فتح وإغلاق ---------- */
  async function open(opts = {}) {
    const taken = [];
    S = { lookId: null, items: [], bg: '#ffffff', sel: null, dirty: false };
    if (opts.lookId) {
      const l = Store.d.looks.find(x => x.id === opts.lookId);
      if (l) {
        S.lookId = l.id; S.bg = l.bg || '#ffffff';
        S.items = l.layout && l.layout.length
          ? l.layout.filter(e => Store.d.items.some(i => i.id === e.itemId)).map(e => Object.assign({ u: Store.uid() }, e))
          : l.items.filter(id => Store.d.items.some(i => i.id === id)).map(id => autoPlace(id, taken));
      }
    } else if (opts.itemIds) {
      S.items = opts.itemIds.map(id => autoPlace(id, taken));
      S.dirty = true;
    }
    el().classList.add('open'); isOpen = true;
    UI.pushBack(closer);
    build();
    S.items.forEach(e => getImg(e.itemId));
  }
  function hide() { isOpen = false; ptrs.clear(); g = null; el().classList.remove('open'); el().innerHTML = ''; }
  // يُستدعى عند ضغط زر الرجوع في أندرويد
  function closer(fromPop) {
    if (fromPop && S && S.dirty && !confirm('الخروج بدون حفظ التصميم؟')) { UI.pushBack(closer); return; }
    hide();
  }
  function closeNow() { if (!isOpen) return; hide(); UI.popBack(closer); }

  /* ---------- التصدير ---------- */
  async function renderCanvas(W, H) {
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d'); x.fillStyle = S.bg; x.fillRect(0, 0, W, H);
    for (const e of S.items) {
      const im = await getImg(e.itemId), w = e.w * W, h = w * (im.naturalHeight / im.naturalWidth);
      x.save(); x.translate(e.x * W, e.y * H); x.rotate(e.rot * Math.PI / 180); x.drawImage(im, -w / 2, -h / 2, w, h); x.restore();
    }
    return c;
  }

  /* ---------- الأوامر ---------- */
  const needSel = () => { const e = cur(); if (!e) UI.toast('اضغطي على قطعة لتحديدها أولاً'); return e; };
  const touch = e => { S.dirty = true; paint(e); };
  Actions.dClose = () => { if (S.dirty && !confirm('الخروج بدون حفظ التصميم؟')) return; closeNow(); };
  Actions.dBig = () => { const e = needSel(); if (e) { e.w = clamp(e.w * 1.12, .06, 1.5); touch(e); } };
  Actions.dSmall = () => { const e = needSel(); if (e) { e.w = clamp(e.w / 1.12, .06, 1.5); touch(e); } };
  Actions.dRotR = () => { const e = needSel(); if (e) { e.rot += 15; touch(e); } };
  Actions.dRotL = () => { const e = needSel(); if (e) { e.rot -= 15; touch(e); } };
  Actions.dFront = () => { const e = needSel(); if (e) { S.items.splice(S.items.indexOf(e), 1); S.items.push(e); S.dirty = true; S.items.forEach(paint); } };
  Actions.dBack = () => { const e = needSel(); if (e) { S.items.splice(S.items.indexOf(e), 1); S.items.unshift(e); S.dirty = true; S.items.forEach(paint); } };
  Actions.dDel = () => { const e = needSel(); if (e) { S.items = S.items.filter(x => x !== e); S.sel = null; S.dirty = true; paintAll(); } };
  Actions.dBg = b => { S.bg = b.dataset.c; S.dirty = true; stage().style.background = S.bg; };

  Actions.dAdd = () => {
    if (!Store.d.items.length) return UI.toast('أضيفي قطعاً إلى الخزانة أولاً');
    pk = new Set();
    const tiles = Store.d.items.map(i => {
      const p = Photos.get(i.id), cut = UI.isPng(p);
      return `<div class="tile" data-act="dPick" data-id="${i.id}"><div class="ph ${cut ? 'cut' : ''}" style="${p ? `background-image:url('${p}')` : ''}">${p ? '' : Outfits.CATS[i.cat][1]}</div>
        <div class="tn">${UI.esc(i.name)}</div></div>`;
    }).join('');
    UI.sheet(`<h2>اختاري القطع</h2><div class="grid">${tiles}</div><div class="btns"><button class="btn" data-act="dAddDo">إضافة إلى اللوحة</button></div>`);
  };
  Actions.dPick = b => { const id = b.dataset.id; if (pk.has(id)) pk.delete(id); else pk.add(id); b.classList.toggle('sel'); };
  Actions.dAddDo = () => {
    const taken = S.items.map(e => (Store.d.items.find(i => i.id === e.itemId) || {}).cat);
    pk.forEach(id => { const e = autoPlace(id, taken); S.items.push(e); getImg(id); });
    if (pk.size) { S.dirty = true; S.sel = S.items[S.items.length - 1].u; paintAll(); }
    UI.close();
  };

  Actions.dShare = async () => {
    if (!S.items.length) return UI.toast('اللوحة فارغة');
    try { const c = await renderCanvas(900, 1200); await UI.shareData(c.toDataURL('image/png'), 'hawshi-look.png', 'إطلالتي'); }
    catch (e) { if (!/cancel/i.test(String(e && e.message))) UI.toast('تعذرت المشاركة'); }
  };

  Actions.dSave = () => {
    if (!S.items.length) return UI.toast('اللوحة فارغة، أضيفي قطعاً أولاً');
    const l = S.lookId && Store.d.looks.find(x => x.id === S.lookId);
    UI.form('حفظ في الإطلالات', [
      { k: 'name', label: 'اسم الإطلالة', value: l ? l.name : '', ph: 'مثال: جامعة وردية' },
      { k: 'occ', label: 'المناسبة', type: 'select', value: l ? l.occ : '', options: [['', 'أي مناسبة']].concat(Outfits.OCCS.map(o => [o, o])) }
    ], {
      saveLabel: 'حفظ الإطلالة',
      onSave(v) {
        const data = {
          name: v.name || 'إطلالة ' + (Store.d.looks.length + 1), occ: v.occ, bg: S.bg,
          items: [...new Set(S.items.map(e => e.itemId))],
          layout: S.items.map(({ itemId, x, y, w, rot }) => ({ itemId, x, y, w, rot }))
        };
        let look = l;
        if (look) Object.assign(look, data); else { look = Object.assign({ id: Store.uid() }, data); Store.d.looks.push(look); }
        Store.save();
        renderCanvas(480, 640).then(c => { Photos.set('L' + look.id, c.toDataURL('image/jpeg', 0.8)); App.render(); });
        S.dirty = false; closeNow(); App.render();
        UI.toast('تم الحفظ في تبويب الإطلالات ✓');
      }
    });
  };

  return { open, isOpen: () => isOpen };
})();
