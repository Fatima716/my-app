/* ============================================================
   habits.js — العادات اليومية
   - اضغطي الدائرة لتسجيل عادة اليوم
   - النقاط الصغيرة = آخر 7 أيام (اضغطي أي نقطة لتعديل يوم سابق)
   ============================================================ */

const Habits = (() => {
  const ICONS = ['💧', '😴', '📚', '🏃‍♀️', '🧘‍♀️', '🥗', '💊', '🕌', '✍️', '💻', '🧹', '🌱'];
  const list = () => Store.d.habits;
  const find = id => list().find(h => h.id === id);

  // عدد الأيام المتتالية (إن لم تسجّلي اليوم بعد، نبدأ العد من أمس)
  function streak(h) {
    let n = 0, d = new Date();
    if (!h.days[UI.iso(d)]) d.setDate(d.getDate() - 1);
    while (h.days[UI.iso(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  }

  function lastWeek() {
    const out = [];
    for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); out.push(UI.iso(d)); }
    return out;
  }

  function render() {
    const today = UI.iso();
    const hs = list();
    if (!hs.length) return '<div class="empty">لم تضيفي عادات بعد 🌱<br>اضغطي + وابدئي بعادة واحدة صغيرة</div>';

    const doneN = hs.filter(h => h.days[today]).length;
    const pct = Math.round(doneN / hs.length * 100);
    const week = lastWeek();

    const rows = hs.map(h => {
      const s = streak(h);
      const dots = week.map(d => `<button class="wd ${h.days[d] ? 'on' : ''}" data-act="habitDay" data-id="${h.id}" data-d="${d}" aria-label="${d}"></button>`).join('');
      return `<div class="card habit">
        <button class="check big ${h.days[today] ? 'on' : ''}" data-act="habitDay" data-id="${h.id}" data-d="${today}">${h.days[today] ? '✓' : h.icon}</button>
        <div class="grow" data-act="habitEdit" data-id="${h.id}">
          <div class="t-title">${UI.esc(h.name)}</div>
          <div class="week">${dots}</div>
        </div>
        ${s > 0 ? `<div class="streak">🔥 ${s}</div>` : ''}
      </div>`;
    }).join('');

    return `<div class="card"><b>${UI.fmtDate(today)}</b>
      <div class="muted">أنجزتِ ${doneN} من ${hs.length} عادات</div>
      <div class="bar"><i style="width:${pct}%"></i></div></div>${rows}`;
  }

  function edit(h) {
    UI.form(h ? 'تعديل العادة' : 'عادة جديدة', [
      { k: 'name', label: 'اسم العادة', value: h && h.name, req: true, ph: 'مثال: شرب 8 أكواب ماء' },
      { k: 'icon', label: 'الأيقونة', type: 'select', value: h ? h.icon : ICONS[0], options: ICONS.map(i => [i, i]) }
    ], {
      onSave(v) {
        if (h) Object.assign(h, v);
        else list().push({ id: Store.uid(), name: v.name, icon: v.icon, days: {} });
        Store.save(); App.render();
      },
      onDelete: h && (() => { Store.d.habits = list().filter(x => x.id !== h.id); Store.save(); App.render(); })
    });
  }

  Actions.habitDay = el => {
    const h = find(el.dataset.id), d = el.dataset.d;
    if (!h) return;
    if (h.days[d]) delete h.days[d]; else h.days[d] = 1;
    Store.save(); App.render();
  };
  Actions.habitEdit = el => edit(find(el.dataset.id));

  return { title: 'العادات', render, add: () => edit(null) };
})();
