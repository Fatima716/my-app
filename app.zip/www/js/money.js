/* ============================================================
   money.js — متتبع المصاريف والدخل
   ============================================================ */

const Money = (() => {
  let ym = UI.iso().slice(0, 7);   // الشهر المعروض: 2026-11

  const OUT = { 'طعام': '🍽️', 'مواصلات': '🚗', 'فواتير': '💡', 'تسوق': '🛍️', 'صحة': '💊', 'دراسة': '📚', 'ترفيه': '🎬', 'أخرى': '📦' };
  const INC = { 'راتب': '💼', 'أبحاث/عمل حر': '✍️', 'هدية': '🎁', 'أخرى': '💰' };
  const catsOf = type => type === 'in' ? INC : OUT;

  const cur = () => Store.d.meta.currency;
  const find = id => Store.d.tx.find(t => t.id === id);

  function shift(n) {
    const [y, m] = ym.split('-').map(Number);
    const d = new Date(y, m - 1 + n, 1);
    ym = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  }

  function render() {
    const [y, m] = ym.split('-').map(Number);
    const txs = Store.d.tx.filter(t => t.date.startsWith(ym))
      .sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : b.id.localeCompare(a.id));
    const sum = type => txs.filter(t => t.type === type).reduce((s, t) => s + t.amount, 0);
    const inc = sum('in'), out = sum('out'), bal = inc - out;

    // توزيع المصاريف حسب التصنيف
    const byCat = {};
    txs.filter(t => t.type === 'out').forEach(t => { byCat[t.cat] = (byCat[t.cat] || 0) + t.amount; });
    const top = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
    const cats = top.length ? `<div class="card"><b>المصاريف حسب التصنيف</b>` +
      top.map(([c, v]) => `<div class="cat"><span>${OUT[c] || ''} ${UI.esc(c)}</span>
        <div class="bar"><i style="width:${Math.round(v / out * 100)}%"></i></div><span>${UI.money(v)}</span></div>`).join('') + '</div>' : '';

    const rows = txs.map(t => `<div class="card tx" data-act="txEdit" data-id="${t.id}">
        <div class="ico">${catsOf(t.type)[t.cat] || '💰'}</div>
        <div class="grow"><div class="t-title">${UI.esc(t.note || t.cat)}</div>
          <div class="meta">${UI.esc(t.cat)} · ${UI.fmtShort(t.date)}</div></div>
        <div class="amt ${t.type === 'in' ? 'in' : 'out'}">${t.type === 'in' ? '+' : '−'}${UI.money(t.amount)}</div>
      </div>`).join('');

    return `<div class="month">
        <button data-act="monthNext" aria-label="التالي">›</button>
        <b>${UI.MONTHS[m - 1]} ${y}</b>
        <button data-act="monthPrev" aria-label="السابق">‹</button>
      </div>
      <div class="sum">
        <div class="card"><small>الدخل</small><strong class="in">${UI.money(inc)}</strong></div>
        <div class="card"><small>المصروف</small><strong class="out">${UI.money(out)}</strong></div>
        <div class="card wide"><small>المتبقي (${UI.esc(cur())})</small><strong class="${bal < 0 ? 'out' : 'in'}">${UI.money(bal)}</strong></div>
      </div>${cats}${rows || '<div class="empty">لا توجد عمليات في هذا الشهر<br>اضغطي + لتسجيل أول عملية</div>'}`;
  }

  function fillCats(sel, type, keep) {
    const c = catsOf(type);
    sel.innerHTML = Object.keys(c).map(k => `<option ${k === keep ? 'selected' : ''}>${k}</option>`).join('');
  }

  function edit(t) {
    const type = t ? t.type : 'out';
    const defDate = ym === UI.iso().slice(0, 7) ? UI.iso() : ym + '-01';
    UI.form(t ? 'تعديل العملية' : 'عملية جديدة', [
      { k: 'type', label: 'النوع', type: 'select', value: type, options: [['out', 'مصروف'], ['in', 'دخل']] },
      { k: 'amount', label: 'المبلغ (' + cur() + ')', type: 'number', value: t && t.amount, req: true },
      { k: 'cat', label: 'التصنيف', type: 'select', value: t ? t.cat : 'طعام', options: Object.keys(catsOf(type)).map(k => [k, k]) },
      { k: 'date', label: 'التاريخ', type: 'date', value: t ? t.date : defDate, req: true },
      { k: 'note', label: 'ملاحظة (اختياري)', value: t && t.note }
    ], {
      after() {
        const ty = $('#f_type'), ca = $('#f_cat');
        ty.onchange = () => fillCats(ca, ty.value);   // تتغير التصنيفات حسب النوع
      },
      onSave(v) {
        if (!(v.amount > 0)) { UI.toast('أدخلي مبلغاً صحيحاً'); return false; }
        if (t) Object.assign(t, v);
        else Store.d.tx.push(Object.assign({ id: Store.uid() }, v));
        ym = v.date.slice(0, 7);
        Store.save(); App.render();
      },
      onDelete: t && (() => { Store.d.tx = Store.d.tx.filter(x => x.id !== t.id); Store.save(); App.render(); })
    });
  }

  Actions.monthPrev = () => { shift(-1); App.render(); };
  Actions.monthNext = () => { shift(1); App.render(); };
  Actions.txEdit = el => edit(find(el.dataset.id));

  return { title: 'المصاريف', render, add: () => edit(null) };
})();
