/* ============================================================
   money.js — المال: الحركات، الحسابات، الديون، الميزانيات
   - كل حساب له رصيد يُحسب تلقائياً من: الرصيد الابتدائي + الدخل − المصروف
     ± التحويلات ± حركات الديون المرتبطة به.
   - "إجمالي ما لديك" = مجموع أرصدة كل الحسابات.
   ============================================================ */

const Money = (() => {
  let ym = UI.iso().slice(0, 7);   // الشهر المعروض في تبويب الحركات
  let sub = 'tx';                  // tx | acc | debt | budget

  const OUT = { 'طعام': '🍽️', 'مواصلات': '🚗', 'فواتير': '💡', 'تسوق': '🛍️', 'صحة': '💊', 'دراسة': '📚', 'ترفيه': '🎬', 'أخرى': '📦' };
  const INC = { 'راتب': '💼', 'أبحاث/عمل حر': '✍️', 'هدية': '🎁', 'أخرى': '💰' };
  const catsOf = type => type === 'in' ? INC : OUT;
  const ACC_TYPES = { cash: ['نقد بالبيت', '🏠'], bank: ['مصرف', '🏦'], wallet: ['محفظة إلكترونية', '📱'], purse: ['محفظة جيب', '👛'], save: ['ادخار / جمعية', '🐖'], other: ['أخرى', '💼'] };

  const D = () => Store.d;
  const cur = () => D().meta.currency;
  const fmt = UI.money;
  const accs = () => D().accounts;
  const acc = id => accs().find(a => a.id === id);
  const accName = id => { const a = acc(id); return a ? a.name : ''; };
  const accOptions = (blank) => (blank ? [['', blank]] : []).concat(accs().map(a => [a.id, ACC_TYPES[a.type][1] + ' ' + a.name]));
  const monthOf = s => s.slice(0, 7);
  const sumBy = (arr, f) => arr.reduce((s, x) => s + f(x), 0);

  /* ---------- الحسابات ---------- */
  function balance(a) {
    let b = a.opening || 0;
    D().tx.forEach(t => { if (t.acc === a.id) b += t.type === 'in' ? t.amount : -t.amount; });
    D().transfers.forEach(t => { if (t.from === a.id) b -= t.amount; if (t.to === a.id) b += t.amount; });
    D().debts.forEach(d => {
      const sign = d.dir === 'owe' ? 1 : -1;          // استلفت: يدخل مالٌ، أقرضت: يخرج مال
      if (d.acc === a.id) b += sign * d.amount;
      d.pays.forEach(p => { if (p.acc === a.id) b -= sign * p.amount; });
    });
    return b;
  }
  const totalMoney = () => sumBy(accs(), balance);

  /* ---------- الديون ---------- */
  const remaining = d => d.amount - sumBy(d.pays, p => p.amount);
  const debtTotals = () => ({
    owe: sumBy(D().debts.filter(d => d.dir === 'owe'), remaining),
    owed: sumBy(D().debts.filter(d => d.dir === 'owed'), remaining)
  });
  const findDebt = id => D().debts.find(d => d.id === id);

  /* ---------- الميزانيات ---------- */
  function spent(b) {
    return sumBy(D().tx.filter(t => t.type === 'out' && t.date >= b.start && t.date <= b.end &&
      (!b.acc || t.acc === b.acc) && (!b.cat || t.cat === b.cat)), t => t.amount);
  }

  /* ============ البطاقة العلوية: إجمالي ما لديك ============ */
  function hero() {
    if (!accs().length) {
      return `<div class="card hero"><small>إجمالي ما لديك</small>
        <div class="muted">أضيفي حساباً (مصرف، نقد بالبيت، محفظة...) من تبويب «الحسابات» ليُحسب إجمالي أموالك وينقص تلقائياً عند الصرف.</div></div>`;
    }
    const tot = totalMoney(), { owe, owed } = debtTotals();
    const line = (owe || owed) ? `<div class="hero-sub">عليك ${fmt(owe)} · لك ${fmt(owed)} · <b>الصافي بعد الديون ${fmt(tot - owe + owed)}</b></div>` : '';
    return `<div class="card hero"><small>إجمالي ما لديك (${UI.esc(cur())})</small>
      <strong class="${tot < 0 ? 'out' : ''}">${fmt(tot)}</strong>${line}</div>`;
  }

  /* ============ تبويب الحركات ============ */
  function shift(n) {
    const [y, m] = ym.split('-').map(Number);
    const d = new Date(y, m - 1 + n, 1);
    ym = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  }
  const monthTx = () => D().tx.filter(t => t.date.startsWith(ym));

  function viewTx() {
    const [y, m] = ym.split('-').map(Number);
    const txs = monthTx();
    const inc = sumBy(txs.filter(t => t.type === 'in'), t => t.amount);
    const out = sumBy(txs.filter(t => t.type === 'out'), t => t.amount);
    const bal = inc - out;

    const byCat = {};
    txs.filter(t => t.type === 'out').forEach(t => { byCat[t.cat] = (byCat[t.cat] || 0) + t.amount; });
    const top = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
    const cats = top.length ? `<div class="card"><b>المصاريف حسب التصنيف</b>` +
      top.map(([c, v]) => `<div class="cat"><span>${OUT[c] || ''} ${UI.esc(c)}</span>
        <div class="bar"><i style="width:${Math.round(v / out * 100)}%"></i></div><span>${fmt(v)}</span></div>`).join('') + '</div>' : '';

    // الحركات والتحويلات معاً مرتبة بالتاريخ
    const rows = txs.map(t => ({ date: t.date, id: t.id, html: `<div class="card tx" data-act="txEdit" data-id="${t.id}">
        <div class="ico">${catsOf(t.type)[t.cat] || '💰'}</div>
        <div class="grow"><div class="t-title">${UI.esc(t.note || t.cat)}</div>
          <div class="meta">${UI.esc(t.cat)} · ${UI.fmtShort(t.date)}${accName(t.acc) ? ' · ' + UI.esc(accName(t.acc)) : ''}</div></div>
        <div class="amt ${t.type === 'in' ? 'in' : 'out'}">${t.type === 'in' ? '+' : '−'}${fmt(t.amount)}</div></div>` }))
      .concat(D().transfers.filter(t => t.date.startsWith(ym)).map(t => ({ date: t.date, id: t.id, html: `<div class="card tx" data-act="trEdit" data-id="${t.id}">
        <div class="ico">🔁</div>
        <div class="grow"><div class="t-title">تحويل${t.note ? ': ' + UI.esc(t.note) : ''}</div>
          <div class="meta">${UI.esc(accName(t.from))} ← ${UI.esc(accName(t.to))} · ${UI.fmtShort(t.date)}</div></div>
        <div class="amt">${fmt(t.amount)}</div></div>` })))
      .sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : b.id.localeCompare(a.id));

    return `<div class="month">
        <button data-act="monthNext" aria-label="التالي">›</button>
        <b>${UI.MONTHS[m - 1]} ${y}</b>
        <button data-act="monthPrev" aria-label="السابق">‹</button>
      </div>
      <div class="sum">
        <div class="card" data-act="sumDetail" data-type="in"><small>الدخل ✎</small><strong class="in">${fmt(inc)}</strong></div>
        <div class="card" data-act="sumDetail" data-type="out"><small>المصروف ✎</small><strong class="out">${fmt(out)}</strong></div>
        <div class="card wide"><small>صافي هذا الشهر (${UI.esc(cur())})</small><strong class="${bal < 0 ? 'out' : 'in'}">${fmt(bal)}</strong></div>
      </div>${cats}${rows.map(r => r.html).join('') || '<div class="empty">لا توجد عمليات في هذا الشهر<br>اضغطي + لتسجيل أول عملية</div>'}`;
  }

  function fillCats(sel, type, keep) {
    sel.innerHTML = Object.keys(catsOf(type)).map(k => `<option ${k === keep ? 'selected' : ''}>${k}</option>`).join('');
  }

  function editTx(t) {
    const type = t ? t.type : 'out';
    const defDate = ym === UI.iso().slice(0, 7) ? UI.iso() : ym + '-01';
    const lastAcc = acc(D().meta.lastAcc) ? D().meta.lastAcc : (accs()[0] || {}).id || '';
    const fields = [
      { k: 'type', label: 'النوع', type: 'select', value: type, options: [['out', 'مصروف'], ['in', 'دخل']] },
      { k: 'amount', label: 'المبلغ (' + cur() + ')', type: 'number', value: t && t.amount, req: true },
      { k: 'cat', label: 'التصنيف', type: 'select', value: t ? t.cat : 'طعام', options: Object.keys(catsOf(type)).map(k => [k, k]) }
    ];
    if (accs().length) fields.push({ k: 'acc', label: 'من/إلى أي حساب؟', type: 'select', value: t ? t.acc : lastAcc, options: accOptions('بدون حساب') });
    fields.push({ k: 'date', label: 'التاريخ', type: 'date', value: t ? t.date : defDate, req: true },
                { k: 'note', label: 'ملاحظة (اختياري)', value: t && t.note });
    UI.form(t ? 'تعديل العملية' : 'عملية جديدة', fields, {
      after() { const ty = $('#f_type'), ca = $('#f_cat'); ty.onchange = () => fillCats(ca, ty.value); },
      onSave(v) {
        if (!(v.amount > 0)) { UI.toast('أدخلي مبلغاً صحيحاً'); return false; }
        if (v.acc == null) v.acc = t ? t.acc : '';
        if (t) Object.assign(t, v); else D().tx.push(Object.assign({ id: Store.uid() }, v));
        if (v.acc) D().meta.lastAcc = v.acc;
        ym = v.date.slice(0, 7);
        Store.save(); App.render();
      },
      onDelete: t && (() => { D().tx = D().tx.filter(x => x.id !== t.id); Store.save(); App.render(); })
    });
  }

  // الضغط على مربع الدخل/المصروف: تعديل قيم العمليات مباشرة
  function sumSheet(type) {
    const list = monthTx().filter(t => t.type === type)
      .sort((a, b) => a.date < b.date ? 1 : -1);
    const title = (type === 'in' ? 'الدخل' : 'المصروف') + ' — ' + UI.MONTHS[Number(ym.slice(5)) - 1];
    if (!list.length) return UI.toast('لا توجد عمليات لتعديلها في هذا الشهر');
    UI.sheet(`<h2>${title}</h2><p class="muted">عدّلي أي مبلغ ثم اضغطي حفظ. لتعديل التصنيف أو الحساب أو الحذف اضغطي «تفاصيل».</p>` +
      list.map(t => `<div class="card"><div class="look-h"><b>${UI.esc(t.note || t.cat)}</b>
          <button class="chip" data-act="txEdit" data-id="${t.id}">تفاصيل</button></div>
        <div class="meta">${UI.esc(t.cat)} · ${UI.fmtShort(t.date)}</div>
        <input type="number" inputmode="decimal" step="any" value="${t.amount}" data-txid="${t.id}"></div>`).join('') +
      `<div class="btns"><button class="btn" data-act="sumSave">حفظ التعديلات</button></div>`);
  }

  /* ============ تبويب الحسابات ============ */
  function viewAcc() {
    const rows = accs().map(a => {
      const b = balance(a), tp = ACC_TYPES[a.type];
      return `<div class="card tx" data-act="accEdit" data-id="${a.id}"><div class="ico">${tp[1]}</div>
        <div class="grow"><div class="t-title">${UI.esc(a.name)}</div><div class="meta">${tp[0]}</div></div>
        <div class="amt ${b < 0 ? 'out' : ''}">${fmt(b)}</div></div>`;
    }).join('');
    const tr = accs().length > 1 ? '<button class="btn ghost" style="margin-bottom:12px" data-act="trNew">🔁 تحويل بين حسابين</button>' : '';
    return rows ? rows + tr + '<p class="muted">اضغطي على الحساب لتعديل اسمه أو رصيده. الرصيد ينقص تلقائياً عند تسجيل مصروف على هذا الحساب.</p>'
      : '<div class="empty">لا توجد حسابات بعد 🏦<br>اضغطي + وأضيفي مثلاً: «نقد بالبيت»، «المصرف»، «محفظة»</div>';
  }

  function editAcc(a) {
    UI.form(a ? 'تعديل الحساب' : 'حساب جديد', [
      { k: 'name', label: 'اسم الحساب', value: a && a.name, req: true, ph: 'مثال: مصرف الجمهورية' },
      { k: 'type', label: 'النوع', type: 'select', value: a ? a.type : 'cash', options: Object.entries(ACC_TYPES).map(([k, v]) => [k, v[1] + ' ' + v[0]]) },
      { k: 'bal', label: a ? 'الرصيد الحالي (' + cur() + ')' : 'المبلغ الموجود فيه الآن (' + cur() + ')', type: 'number', value: a ? Math.round(balance(a) * 100) / 100 : 0, req: true }
    ], {
      onSave(v) {
        if (a) { a.opening = (a.opening || 0) + (v.bal - balance(a)); a.name = v.name; a.type = v.type; }   // نضبط الرصيد الابتدائي ليصبح الرصيد الحالي = المدخل
        else accs().push({ id: Store.uid(), name: v.name, type: v.type, opening: v.bal });
        Store.save(); App.render();
      },
      onDelete: a && (() => {
        if (!confirm('سيُفصل الحساب عن عملياته (تبقى العمليات نفسها). متأكدة؟')) return;
        D().tx.forEach(t => { if (t.acc === a.id) t.acc = ''; });
        D().debts.forEach(d => { if (d.acc === a.id) d.acc = ''; d.pays.forEach(p => { if (p.acc === a.id) p.acc = ''; }); });
        D().budgets.forEach(b => { if (b.acc === a.id) b.acc = ''; });
        // التحويلات: نحافظ على رصيد الحساب الآخر كما هو ثم نحذف التحويل
        D().transfers.filter(t => t.from === a.id || t.to === a.id).forEach(t => {
          const other = acc(t.from === a.id ? t.to : t.from);
          if (other) other.opening = (other.opening || 0) + (t.from === a.id ? t.amount : -t.amount);
        });
        D().transfers = D().transfers.filter(t => t.from !== a.id && t.to !== a.id);
        D().accounts = accs().filter(x => x.id !== a.id);
        Store.save(); App.render();
      })
    });
  }

  function editTransfer(t) {
    if (accs().length < 2) return UI.toast('تحتاجين حسابين على الأقل');
    UI.form(t ? 'تعديل التحويل' : 'تحويل بين حسابين', [
      { k: 'from', label: 'من حساب', type: 'select', value: t ? t.from : accs()[0].id, options: accOptions() },
      { k: 'to', label: 'إلى حساب', type: 'select', value: t ? t.to : accs()[1].id, options: accOptions() },
      { k: 'amount', label: 'المبلغ (' + cur() + ')', type: 'number', value: t && t.amount, req: true },
      { k: 'date', label: 'التاريخ', type: 'date', value: t ? t.date : UI.iso(), req: true },
      { k: 'note', label: 'ملاحظة (اختياري)', value: t && t.note, ph: 'مثال: سحب من المصرف' }
    ], {
      onSave(v) {
        if (v.from === v.to) { UI.toast('اختاري حسابين مختلفين'); return false; }
        if (!(v.amount > 0)) { UI.toast('أدخلي مبلغاً صحيحاً'); return false; }
        if (t) Object.assign(t, v); else D().transfers.push(Object.assign({ id: Store.uid() }, v));
        Store.save(); App.render();
      },
      onDelete: t && (() => { D().transfers = D().transfers.filter(x => x.id !== t.id); Store.save(); App.render(); })
    });
  }

  /* ============ تبويب الديون ============ */
  function viewDebt() {
    const { owe, owed } = debtTotals();
    const top = `<div class="sum"><div class="card"><small>الديون عليّ</small><strong class="out">${fmt(owe)}</strong></div>
      <div class="card"><small>لي عند الناس</small><strong class="in">${fmt(owed)}</strong></div></div>`;
    const today = UI.iso();
    const open = D().debts.filter(d => remaining(d) > 0.0001).sort((a, b) => (a.due || '9999') < (b.due || '9999') ? -1 : 1);
    const done = D().debts.filter(d => remaining(d) <= 0.0001);
    const card = d => {
      const rem = Math.max(0, remaining(d)), pct = Math.min(100, Math.round((d.amount - rem) / d.amount * 100));
      const late = rem > 0 && d.due && d.due < today;
      return `<div class="card ${rem <= 0 ? 'settled' : ''}" data-act="debtOpen" data-id="${d.id}">
        <div class="look-h"><b>${UI.esc(d.who)}</b><b class="${d.dir === 'owe' ? 'out' : 'in'}">${rem > 0 ? fmt(rem) : '✓ مسدد'}</b></div>
        <div class="meta">${d.dir === 'owe' ? 'عليّ' : 'لي عنده'} · الأصل ${fmt(d.amount)}${d.due ? ` · الموعد <span class="${late ? 'late' : ''}">${UI.fmtDate(d.due)}${late ? ' (متأخر)' : ''}</span>` : ''}</div>
        <div class="bar"><i style="width:${pct}%"></i></div></div>`;
    };
    if (!D().debts.length) return top + '<div class="empty">لا توجد ديون مسجلة 🙌<br>اضغطي + لتسجيل دين (عليكِ أو لكِ)</div>';
    return top + open.map(card).join('') + (done.length ? '<div class="muted" style="margin:14px 0 8px">ديون مسددة</div>' + done.map(card).join('') : '');
  }

  function editDebt(d) {
    UI.form(d ? 'تعديل الدين' : 'دين جديد', [
      { k: 'who', label: 'اسم الشخص', value: d && d.who, req: true },
      { k: 'dir', label: 'نوع الدين', type: 'select', value: d ? d.dir : 'owe', options: [['owe', 'عليّ (أخذت منه مالاً)'], ['owed', 'لي عنده (أقرضته)']] },
      { k: 'amount', label: 'قيمة الدين (' + cur() + ')', type: 'number', value: d && d.amount, req: true },
      { k: 'date', label: 'تاريخ الدين', type: 'date', value: d ? d.date : UI.iso(), req: true },
      { k: 'due', label: 'موعد السداد (اختياري)', type: 'date', value: d && d.due },
      { k: 'acc', label: 'الحساب الذي دخل/خرج منه المبلغ', type: 'select', value: d ? d.acc : '', options: accOptions('بدون ربط بحساب') },
      { k: 'note', label: 'ملاحظة', value: d && d.note }
    ], {
      onSave(v) {
        if (!(v.amount > 0)) { UI.toast('أدخلي مبلغاً صحيحاً'); return false; }
        if (d) Object.assign(d, v); else D().debts.push(Object.assign({ id: Store.uid(), pays: [] }, v));
        Store.save(); App.render();
      },
      onDelete: d && (() => { D().debts = D().debts.filter(x => x.id !== d.id); Store.save(); App.render(); })
    });
  }

  function debtSheet(d) {
    const rem = remaining(d);
    const pays = d.pays.slice().sort((a, b) => a.date < b.date ? 1 : -1).map(p =>
      `<div class="card look-h"><span>${UI.fmtShort(p.date)} · <b>${fmt(p.amount)}</b>${accName(p.acc) ? ' · ' + UI.esc(accName(p.acc)) : ''}</span>
        <button class="chip" data-act="debtPayDel" data-id="${d.id}" data-p="${p.id}">حذف</button></div>`).join('');
    UI.sheet(`<h2>${UI.esc(d.who)}</h2>
      <div class="sum"><div class="card"><small>قيمة الدين</small><strong>${fmt(d.amount)}</strong></div>
        <div class="card"><small>المتبقي</small><strong class="${d.dir === 'owe' ? 'out' : 'in'}">${fmt(Math.max(0, rem))}</strong></div></div>
      <p class="muted">${d.dir === 'owe' ? 'عليّ' : 'لي عنده'}${d.due ? ' · الموعد ' + UI.fmtDate(d.due) : ''}${d.note ? '<br>' + UI.esc(d.note) : ''}</p>
      ${pays ? '<b>الدفعات</b><div style="margin-top:8px">' + pays + '</div>' : ''}
      <div class="btns">${rem > 0 ? `<button class="btn" data-act="debtPay" data-id="${d.id}">${d.dir === 'owe' ? 'تسديد دفعة' : 'استلام دفعة'}</button>` : ''}
        <button class="btn ghost" data-act="debtEdit" data-id="${d.id}">تعديل</button></div>`);
  }

  function payForm(d) {
    const rem = remaining(d);
    UI.form(d.dir === 'owe' ? 'تسديد دفعة لـ ' + d.who : 'دفعة مستلمة من ' + d.who, [
      { k: 'amount', label: 'المبلغ (المتبقي ' + fmt(rem) + ')', type: 'number', value: rem, req: true },
      { k: 'date', label: 'التاريخ', type: 'date', value: UI.iso(), req: true },
      { k: 'acc', label: d.dir === 'owe' ? 'من أي حساب دفعتِ؟' : 'إلى أي حساب دخل المبلغ؟', type: 'select', value: d.acc || '', options: accOptions('بدون ربط بحساب') }
    ], {
      saveLabel: 'تسجيل الدفعة',
      onSave(v) {
        if (!(v.amount > 0)) { UI.toast('أدخلي مبلغاً صحيحاً'); return false; }
        if (v.amount > rem + 0.0001) { UI.toast('المبلغ أكبر من المتبقي (' + fmt(rem) + ')'); return false; }
        d.pays.push({ id: Store.uid(), date: v.date, amount: v.amount, acc: v.acc || '' });
        Store.save(); App.render();
      }
    });
  }

  /* ============ تبويب الميزانيات ============ */
  function viewBudget() {
    if (!D().budgets.length) return '<div class="empty">لا توجد ميزانيات 🎯<br>حددي مبلغاً تصرفينه خلال شهر أو سنة أو عدة أشهر، ومن حساب معين إن أردتِ</div>';
    const today = UI.iso();
    const list = D().budgets.slice().sort((a, b) => a.end < b.end ? -1 : 1);
    return list.map(b => {
      const sp = spent(b), left = b.amount - sp, pct = Math.min(100, Math.round(sp / b.amount * 100));
      const cls = sp > b.amount ? 'bad' : sp / b.amount >= 0.8 ? 'warn' : '';
      let status;
      if (today < b.start) status = 'تبدأ بعد ' + UI.diffDays(b.start, today) + ' يوم';
      else if (today > b.end) status = left >= 0 ? 'انتهت · وفّرتِ ' + fmt(left) : 'انتهت · تجاوزتِ بـ ' + fmt(-left);
      else {
        const days = UI.diffDays(b.end, today) + 1;
        status = left > 0 ? `باقي ${days} يوم · يمكنك صرف ${fmt(left / days)} يومياً` : `باقي ${days} يوم · تجاوزتِ الميزانية`;
      }
      const scope = [b.acc ? accName(b.acc) : 'كل الحسابات', b.cat || 'كل التصنيفات'].join(' · ');
      return `<div class="card" data-act="budgetEdit" data-id="${b.id}">
        <div class="look-h"><b>${UI.esc(b.name)}</b><span class="${left < 0 ? 'out' : 'in'}">${left < 0 ? '−' : ''}${fmt(Math.abs(left))} ${left < 0 ? 'زيادة' : 'متبقي'}</span></div>
        <div class="meta">${UI.fmtShort(b.start)} ← ${UI.fmtShort(b.end)} · ${UI.esc(scope)}</div>
        <div class="bar"><i class="${cls}" style="width:${pct}%"></i></div>
        <div class="meta">صُرف ${fmt(sp)} من ${fmt(b.amount)} · ${status}</div></div>`;
    }).join('');
  }

  function presetDates(p) {
    const t = new Date(), y = t.getFullYear(), m = t.getMonth();
    const last = (yy, mm) => UI.iso(new Date(yy, mm + 1, 0));
    if (p === 'month') return [UI.iso(new Date(y, m, 1)), last(y, m)];
    if (p === 'year') return [y + '-01-01', y + '-12-31'];
    if (p === '3m' || p === '6m') { const n = p === '3m' ? 3 : 6; return [UI.iso(new Date(y, m, 1)), last(y, m + n - 1)]; }
    return null;
  }

  function editBudget(b) {
    const today = UI.iso();
    const [s0, e0] = presetDates('month');
    UI.form(b ? 'تعديل الميزانية' : 'ميزانية جديدة', [
      { k: 'name', label: 'الاسم', value: b && b.name, req: true, ph: 'مثال: مصروف نوفمبر' },
      { k: 'amount', label: 'المبلغ (' + cur() + ')', type: 'number', value: b && b.amount, req: true },
      { k: 'preset', label: 'مدة جاهزة', type: 'select', value: '', options: [['', 'اختاري مدة جاهزة (أو حددي التواريخ بنفسك)'], ['month', 'هذا الشهر'], ['3m', 'هذا الشهر + شهران'], ['6m', 'هذا الشهر + 5 أشهر'], ['year', 'هذه السنة']] },
      { k: 'start', label: 'من تاريخ', type: 'date', value: b ? b.start : s0, req: true },
      { k: 'end', label: 'إلى تاريخ', type: 'date', value: b ? b.end : e0, req: true },
      { k: 'acc', label: 'يُصرف من أي حساب؟', type: 'select', value: b ? b.acc : '', options: accOptions('كل الحسابات') },
      { k: 'cat', label: 'التصنيف', type: 'select', value: b ? b.cat : '', options: [['', 'كل التصنيفات']].concat(Object.keys(OUT).map(k => [k, k])) }
    ], {
      after() {
        $('#f_preset').onchange = e => {
          const r = presetDates(e.target.value);
          if (r) { $('#f_start').value = r[0]; $('#f_end').value = r[1]; }
        };
      },
      onSave(v) {
        delete v.preset;
        if (!(v.amount > 0)) { UI.toast('أدخلي مبلغاً صحيحاً'); return false; }
        if (v.end < v.start) { UI.toast('تاريخ النهاية قبل البداية'); return false; }
        if (b) Object.assign(b, v); else D().budgets.push(Object.assign({ id: Store.uid() }, v));
        Store.save(); App.render();
      },
      onDelete: b && (() => { D().budgets = D().budgets.filter(x => x.id !== b.id); Store.save(); App.render(); })
    });
  }

  /* ============ العرض الرئيسي ============ */
  function render() {
    const tabs = [['tx', 'الحركات'], ['acc', 'الحسابات'], ['debt', 'الديون'], ['budget', 'الميزانيات']]
      .map(([k, l]) => `<button class="${sub === k ? 'on' : ''}" data-act="moneySub" data-v="${k}">${l}</button>`).join('');
    const body = { tx: viewTx, acc: viewAcc, debt: viewDebt, budget: viewBudget }[sub]();
    return `${hero()}<div class="seg">${tabs}</div>${body}`;
  }

  Actions.moneySub = el => { sub = el.dataset.v; App.render(); };
  Actions.monthPrev = () => { shift(-1); App.render(); };
  Actions.monthNext = () => { shift(1); App.render(); };
  Actions.txEdit = el => editTx(D().tx.find(t => t.id === el.dataset.id));
  Actions.sumDetail = el => sumSheet(el.dataset.type);
  Actions.sumSave = () => {
    let n = 0;
    document.querySelectorAll('#sheet-body [data-txid]').forEach(inp => {
      const t = D().tx.find(x => x.id === inp.dataset.txid), v = parseFloat(inp.value.replace(',', '.'));
      if (t && v > 0 && v !== t.amount) { t.amount = v; n++; }
    });
    Store.save(); UI.close(); App.render();
    UI.toast(n ? 'تم تعديل ' + n + ' عملية' : 'لم يتغير شيء');
  };
  Actions.accEdit = el => editAcc(acc(el.dataset.id));
  Actions.trNew = () => editTransfer(null);
  Actions.trEdit = el => editTransfer(D().transfers.find(t => t.id === el.dataset.id));
  Actions.debtOpen = el => debtSheet(findDebt(el.dataset.id));
  Actions.debtEdit = el => editDebt(findDebt(el.dataset.id));
  Actions.debtPay = el => payForm(findDebt(el.dataset.id));
  Actions.debtPayDel = el => {
    const d = findDebt(el.dataset.id);
    if (!confirm('حذف هذه الدفعة؟ سيعود المبلغ إلى المتبقي.')) return;
    d.pays = d.pays.filter(p => p.id !== el.dataset.p);
    Store.save(); App.render(); debtSheet(d);
  };
  Actions.budgetEdit = el => editBudget(D().budgets.find(b => b.id === el.dataset.id));

  return {
    title: 'المال', render,
    add: () => ({ tx: () => editTx(null), acc: () => editAcc(null), debt: () => editDebt(null), budget: () => editBudget(null) }[sub]())
  };
})();
