/* ============================================================
   outfits.js — تنسيق الملابس
   ثلاثة أقسام: الخزانة (القطع) / الإطلالات (المحفوظة) / اقتراح (تنسيق تلقائي)
   ============================================================ */

const Outfits = (() => {
  let sub = 'closet', catFilter = '', ed = null;
  let sg = { occ: '', season: seasonNow(), result: null, msg: '' };

  const CATS = { top: ['علوي', '👚'], bottom: ['سفلي', '👖'], dress: ['فستان', '👗'], outer: ['عباية/جاكيت', '🧥'], shoes: ['حذاء', '👟'], bag: ['حقيبة', '👜'], acc: ['إكسسوار', '💍'] };
  const COLORS = { 'أسود': '#222', 'أبيض': '#f5f5f5', 'رمادي': '#9a9a9a', 'بيج': '#d9c3a0', 'بني': '#7b5037', 'كحلي': '#1f2f57',
    'أزرق': '#3d7bd6', 'أخضر': '#3f9a69', 'أصفر': '#e8c53a', 'برتقالي': '#e8893a', 'أحمر': '#d64550', 'وردي': '#f0a5bd', 'بنفسجي': '#8a63c9' };
  const NEUTRAL = ['أسود', 'أبيض', 'رمادي', 'بيج', 'بني', 'كحلي'];
  const SEASONS = ['صيف', 'شتاء', 'ربيع/خريف'];
  const OCCS = ['يومي', 'جامعة/عمل', 'رسمي', 'مناسبة/سهرة', 'رياضة', 'بيت'];
  // ألوان متناسقة مع بعضها (غير المحايدة)
  const FRIENDS = [['أزرق', 'أخضر'], ['وردي', 'بنفسجي'], ['أحمر', 'وردي'], ['أصفر', 'برتقالي'], ['برتقالي', 'أحمر'], ['أزرق', 'برتقالي'], ['بنفسجي', 'أصفر'], ['أخضر', 'أصفر']];

  function seasonNow() {
    const m = new Date().getMonth();
    return m >= 5 && m <= 8 ? 'صيف' : (m === 11 || m <= 1) ? 'شتاء' : 'ربيع/خريف';
  }

  const items = () => Store.d.items;
  const looks = () => Store.d.looks;
  const item = id => items().find(i => i.id === id);
  const look = id => looks().find(l => l.id === id);

  function ph(i, cls = '') {
    const p = Photos.get(i.id);
    return `<div class="ph ${cls}" style="${p ? `background-image:url('${p}')` : `background:${COLORS[i.color] ? COLORS[i.color] + '33' : 'var(--soft)'}`}">${p ? '' : CATS[i.cat][1]}</div>`;
  }
  function tile(i, act, extra = '') {
    const c = COLORS[i.color];
    return `<div class="tile ${extra}" data-act="${act}" data-id="${i.id}">${ph(i)}
      <div class="tn">${c ? `<span class="dot" style="background:${c}"></span>` : ''}${UI.esc(i.name)}</div></div>`;
  }

  /* ---------------- الخزانة ---------------- */
  function closet() {
    const all = items();
    if (!all.length) return '<div class="empty">خزانتك فارغة 👗<br>اضغطي + وأضيفي أول قطعة (يفضّل تصوير القطعة)</div>';
    const chips = [['', 'الكل', all.length]].concat(Object.entries(CATS).map(([k, v]) =>
      [k, v[0], all.filter(i => i.cat === k).length])).filter(c => c[0] === '' || c[2] > 0)
      .map(([k, l, n]) => `<button class="chip ${catFilter === k ? 'on' : ''}" data-act="outCat" data-v="${k}">${l} (${n})</button>`).join('');
    const shown = all.filter(i => !catFilter || i.cat === catFilter);
    return `<div class="chips">${chips}</div><div class="grid">${shown.map(i => tile(i, 'itemEdit')).join('')}</div>`;
  }

  function editItem(i) {
    UI.form(i ? 'تعديل القطعة' : 'قطعة جديدة', [
      { k: 'photo', label: 'الصورة', type: 'photo', value: i ? Photos.get(i.id) : '' },
      { k: 'name', label: 'الاسم', value: i && i.name, req: true, ph: 'مثال: بلوزة بيضاء قطن' },
      { k: 'cat', label: 'النوع', type: 'select', value: i ? i.cat : 'top', options: Object.entries(CATS).map(([k, v]) => [k, v[0]]) },
      { k: 'color', label: 'اللون', type: 'select', value: i ? i.color : 'أسود', options: Object.keys(COLORS).map(c => [c, c]) },
      { k: 'season', label: 'الموسم', type: 'select', value: i ? i.season : '', options: [['', 'كل المواسم']].concat(SEASONS.map(s => [s, s])) },
      { k: 'occ', label: 'المناسبة', type: 'select', value: i ? i.occ : '', options: [['', 'أي مناسبة']].concat(OCCS.map(o => [o, o])) }
    ], {
      onSave(v) {
        const photo = v.photo; delete v.photo;
        let target = i;
        if (i) Object.assign(i, v);
        else { target = Object.assign({ id: Store.uid() }, v); items().push(target); }
        if (photo) Photos.set(target.id, photo);
        Store.save(); App.render();
      },
      onDelete: i && (() => {
        Store.d.items = items().filter(x => x.id !== i.id);
        looks().forEach(l => { l.items = l.items.filter(x => x !== i.id); });   // نزيلها من الإطلالات
        Photos.del(i.id); Store.save(); App.render();
      })
    });
  }

  /* ---------------- الإطلالات ---------------- */
  function lastWorn(lookId) {
    const w = Store.d.worn.filter(x => x.look === lookId).map(x => x.date).sort().pop();
    if (!w) return 'لم تُلبس بعد';
    const n = -UI.diffDays(w, UI.iso());
    return n === 0 ? 'لُبست اليوم' : 'آخر لبس: قبل ' + n + ' يوم';
  }

  function looksView() {
    const ls = looks().map(l => {
      const its = l.items.map(item).filter(Boolean);
      return `<div class="card">
        <div class="look-h"><b>${UI.esc(l.name)}</b><span class="muted">${UI.esc(l.occ || '')}</span></div>
        <div class="muted">${lastWorn(l.id)}</div>
        <div class="mini">${its.map(i => ph(i)).join('')}</div>
        <div class="btns"><button class="btn sm" data-act="lookWear" data-id="${l.id}">ألبستها اليوم</button>
          <button class="btn sm ghost" data-act="lookEdit" data-id="${l.id}">تعديل</button></div></div>`;
    }).join('');
    const log = Store.d.worn.slice().sort((a, b) => a.date < b.date ? 1 : -1).slice(0, 7)
      .map(w => `<div class="meta">${UI.fmtDate(w.date)} — ${UI.esc((look(w.look) || {}).name || w.items.map(x => (item(x) || {}).name).filter(Boolean).join(' + '))}</div>`).join('');
    return (ls || '<div class="empty">لا توجد إطلالات محفوظة<br>اضغطي + لتكوين إطلالة من قطعك، أو جرّبي تبويب «اقتراح»</div>') +
      (log ? `<div class="card"><b>آخر ما لبستيه</b>${log}</div>` : '');
  }

  function lookSheet(l) {
    if (!items().length) return UI.toast('أضيفي قطعاً إلى الخزانة أولاً');
    ed = { id: l && l.id, sel: new Set(l ? l.items : []) };
    UI.sheet(`<h2>${l ? 'تعديل الإطلالة' : 'إطلالة جديدة'}</h2>
      <label>الاسم<input id="l_name" value="${UI.esc(l ? l.name : '')}" placeholder="مثال: جامعة بسيطة"></label>
      <label>المناسبة<select id="l_occ"><option value="">أي مناسبة</option>${OCCS.map(o => `<option ${l && l.occ === o ? 'selected' : ''}>${o}</option>`).join('')}</select></label>
      <div class="muted" style="margin-bottom:8px">اختاري القطع:</div>
      <div class="grid">${items().map(i => tile(i, 'lookPick', ed.sel.has(i.id) ? 'sel' : '')).join('')}</div>
      <div class="btns"><button class="btn" data-act="lookSave">حفظ</button>${l ? '<button class="btn danger" data-act="lookDel">حذف</button>' : ''}</div>`);
  }

  function wear(ids, lookId) {
    const today = UI.iso();
    Store.d.worn = Store.d.worn.filter(w => w.date !== today);   // إطلالة واحدة لكل يوم
    Store.d.worn.push({ date: today, look: lookId || null, items: ids });
    Store.save(); UI.toast('تم تسجيل إطلالة اليوم ✓'); App.render();
  }

  /* ---------------- الاقتراح التلقائي ---------------- */
  function pairScore(a, b) {
    if (NEUTRAL.includes(a) || NEUTRAL.includes(b)) return 2;     // المحايد يناسب الكل
    if (a === b) return 1;
    return FRIENDS.some(p => p.includes(a) && p.includes(b)) ? 1 : -2;
  }
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];

  function suggest() {
    const ok = i => (!sg.occ || !i.occ || i.occ === sg.occ) && (!sg.season || !i.season || i.season === sg.season);
    const pool = items().filter(ok), by = c => pool.filter(i => i.cat === c);
    const tops = by('top'), bottoms = by('bottom'), dresses = by('dress'), outers = by('outer'), shoes = by('shoes'), bags = by('bag'), accs = by('acc');
    if (!dresses.length && !(tops.length && bottoms.length)) {
      sg.result = null; sg.msg = 'لا تكفي القطع لهذه المناسبة والموسم. أضيفي علوي + سفلي (أو فستان).'; return;
    }
    // ما لُبس آخر 3 أيام نقلّل احتمال تكراره
    const recent = new Set();
    Store.d.worn.filter(w => UI.diffDays(UI.iso(), w.date) <= 3).forEach(w => w.items.forEach(x => recent.add(x)));

    const cands = [];
    for (let n = 0; n < 80; n++) {
      const set = [];
      if (dresses.length && (!(tops.length && bottoms.length) || Math.random() < 0.4)) set.push(pick(dresses));
      else set.push(pick(tops), pick(bottoms));
      if (outers.length && (sg.season === 'شتاء' || Math.random() < 0.3)) set.push(pick(outers));
      if (shoes.length) set.push(pick(shoes));
      if (bags.length && Math.random() < 0.5) set.push(pick(bags));
      if (accs.length && Math.random() < 0.4) set.push(pick(accs));
      let score = Math.random() * 1.5;
      for (let a = 0; a < set.length; a++) {
        if (recent.has(set[a].id)) score -= 3;
        for (let b = a + 1; b < set.length; b++) score += pairScore(set[a].color, set[b].color);
      }
      cands.push({ ids: set.map(i => i.id), score });
    }
    const key = a => a.slice().sort().join();
    const old = sg.result ? key(sg.result) : '';
    const best = cands.sort((a, b) => b.score - a.score).filter(c => key(c.ids) !== old).slice(0, 5);
    sg.result = pick(best).ids; sg.msg = '';
  }

  function suggestView() {
    const opt = (arr, cur, blank) => `<option value="">${blank}</option>` + arr.map(x => `<option ${x === cur ? 'selected' : ''}>${x}</option>`).join('');
    const controls = `<div class="card">
      <label>المناسبة<select data-chg="sgOcc">${opt(OCCS, sg.occ, 'أي مناسبة')}</select></label>
      <label style="margin:0">الموسم<select data-chg="sgSeason">${opt(SEASONS, sg.season, 'كل المواسم')}</select></label></div>`;
    let res = '';
    if (sg.msg) res = `<div class="banner">${sg.msg}</div>`;
    else if (sg.result) {
      res = `<div class="card"><b>اقتراحي لك</b><div class="grid" style="margin-top:10px">${sg.result.map(id => item(id)).filter(Boolean).map(i => tile(i, 'noop')).join('')}</div>
        <div class="btns"><button class="btn sm" data-act="sgWear">ألبسها اليوم</button>
        <button class="btn sm ghost" data-act="sgSave">حفظ كإطلالة</button></div></div>`;
    }
    return controls + res + `<button class="btn" data-act="sgGo">${sg.result ? 'اقتراح آخر 🔄' : 'اقترحي لي إطلالة ✨'}</button>
      <p class="muted">التنسيق يعتمد على توافق الألوان، ويتجنب ما لبستيه في آخر 3 أيام.</p>`;
  }

  /* ---------------- العرض الرئيسي ---------------- */
  function render() {
    const tabs = [['closet', 'الخزانة'], ['looks', 'الإطلالات'], ['suggest', 'اقتراح']]
      .map(([k, l]) => `<button class="${sub === k ? 'on' : ''}" data-act="outSub" data-v="${k}">${l}</button>`).join('');
    const body = sub === 'closet' ? closet() : sub === 'looks' ? looksView() : suggestView();
    return `<div class="seg">${tabs}</div>${body}`;
  }

  Actions.noop = () => {};
  Actions.outSub = el => { sub = el.dataset.v; App.render(); };
  Actions.outCat = el => { catFilter = el.dataset.v; App.render(); };
  Actions.itemEdit = el => editItem(item(el.dataset.id));
  Actions.lookEdit = el => lookSheet(look(el.dataset.id));
  Actions.lookPick = el => {
    const id = el.dataset.id;
    if (ed.sel.has(id)) ed.sel.delete(id); else ed.sel.add(id);
    el.classList.toggle('sel');
  };
  Actions.lookSave = () => {
    if (ed.sel.size < 2) return UI.toast('اختاري قطعتين على الأقل');
    const name = $('#l_name').value.trim() || 'إطلالة ' + (looks().length + 1);
    const data = { name, occ: $('#l_occ').value, items: [...ed.sel] };
    if (ed.id) Object.assign(look(ed.id), data); else looks().push(Object.assign({ id: Store.uid() }, data));
    Store.save(); UI.close(); App.render();
  };
  Actions.lookDel = () => {
    if (!confirm('حذف الإطلالة؟')) return;
    Store.d.looks = looks().filter(l => l.id !== ed.id);
    Store.save(); UI.close(); App.render();
  };
  Actions.lookWear = el => { const l = look(el.dataset.id); wear(l.items.filter(item), l.id); };
  Actions.sgOcc = el => { sg.occ = el.value; sg.result = null; sg.msg = ''; App.render(); };
  Actions.sgSeason = el => { sg.season = el.value; sg.result = null; sg.msg = ''; App.render(); };
  Actions.sgGo = () => { suggest(); App.render(); };
  Actions.sgWear = () => wear(sg.result, null);
  Actions.sgSave = () => {
    looks().push({ id: Store.uid(), name: 'إطلالة ' + (looks().length + 1), occ: sg.occ, items: sg.result.slice() });
    Store.save(); UI.toast('تم الحفظ في تبويب الإطلالات');
  };

  return {
    title: 'الملابس', render,
    add: () => sub === 'looks' ? lookSheet(null) : (sub = 'closet', editItem(null))
  };
})();
