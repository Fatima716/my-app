/* ============================================================
   outfits.js — الملابس
   الخزانة · الإطلالات (+ سجل اللبس بالصور) · اقتراح · إحصائيات
   ============================================================ */

const Outfits = (() => {
  let sub = 'closet', catFilter = '', wornAll = false;
  let sg = { occ: '', season: seasonNow(), result: null, msg: '' };
  let ed = null;        // نافذة تكوين إطلالة سريعة
  let we = null;        // نافذة تعديل سجل اللبس
  let batch = null;     // مراجعة الصور المتعددة
  let cutSrc = null;    // الصورة الأصلية للقطعة قيد التعديل (لإزالة الخلفية)

  const CATS = { top: ['علوي', '👚'], bottom: ['سفلي', '👖'], dress: ['فستان', '👗'], outer: ['عباية/جاكيت', '🧥'], shoes: ['حذاء', '👟'], bag: ['حقيبة', '👜'], acc: ['إكسسوار', '💍'] };
  const COLORS = { 'أسود': '#222', 'أبيض': '#f5f5f5', 'رمادي': '#9a9a9a', 'بيج': '#d9c3a0', 'بني': '#7b5037', 'كحلي': '#1f2f57',
    'أزرق': '#3d7bd6', 'أخضر': '#3f9a69', 'أصفر': '#e8c53a', 'برتقالي': '#e8893a', 'أحمر': '#d64550', 'وردي': '#f0a5bd', 'بنفسجي': '#8a63c9' };
  const NEUTRAL = ['أسود', 'أبيض', 'رمادي', 'بيج', 'بني', 'كحلي'];
  const SEASONS = ['صيف', 'شتاء', 'ربيع/خريف'];
  const OCCS = ['يومي', 'جامعة/عمل', 'رسمي', 'مناسبة/سهرة', 'رياضة', 'بيت'];
  // ألوان متناسقة مع بعضها (غير المحايدة)
  const FRIENDS = [['أزرق', 'أخضر'], ['وردي', 'بنفسجي'], ['أحمر', 'وردي'], ['أصفر', 'برتقالي'], ['برتقالي', 'أحمر'], ['أزرق', 'برتقالي'], ['بنفسجي', 'أصفر'], ['أخضر', 'أصفر']];

  function seasonNow() {
    const m = new Date().getMonth();
    return m >= 5 && m <= 8 ? 'صيف' : (m === 11 || m <= 1) ? 'شتاء' : 'ربيع/خريف';
  }

  const items = () => Store.d.items;
  const looks = () => Store.d.looks;
  const worn = () => Store.d.worn;
  const item = id => items().find(i => i.id === id);
  const look = id => looks().find(l => l.id === id);
  const esc = UI.esc;

  function ph(i, cls = '') {
    const p = Photos.get(i.id), cut = UI.isPng(p);
    const st = p ? `background-image:url('${p}')` : `background:${COLORS[i.color] ? COLORS[i.color] + '33' : 'var(--soft)'}`;
    return `<div class="ph ${cut ? 'cut' : ''} ${cls}" style="${st}">${p ? '' : CATS[i.cat][1]}</div>`;
  }
  function tile(i, act, extra = '') {
    const c = COLORS[i.color];
    return `<div class="tile ${extra}" data-act="${act}" data-id="${i.id}">${ph(i)}
      <div class="tn">${c ? `<span class="dot" style="background:${c}"></span>` : ''}${esc(i.name)}</div></div>`;
  }
  const colorOptions = cur => Object.keys(COLORS).map(c => `<option ${c === cur ? 'selected' : ''}>${c}</option>`).join('');
  const catOptions = cur => Object.entries(CATS).map(([k, v]) => `<option value="${k}" ${k === cur ? 'selected' : ''}>${v[0]}</option>`).join('');

  /* ======================= الخزانة ======================= */
  function closet() {
    const all = items();
    const bar = '<div class="btns" style="margin:0 0 12px"><button class="btn sm" data-act="outBatch">📷 رفع عدة صور</button></div>';
    if (!all.length) return bar + '<div class="empty">خزانتك فارغة 👗<br>اضغطي + لإضافة قطعة، أو «رفع عدة صور» لإضافة الكثير دفعة واحدة</div>';
    const chips = [['', 'الكل', all.length]].concat(Object.entries(CATS).map(([k, v]) =>
      [k, v[0], all.filter(i => i.cat === k).length])).filter(c => c[0] === '' || c[2] > 0)
      .map(([k, l, n]) => `<button class="chip ${catFilter === k ? 'on' : ''}" data-act="outCat" data-v="${k}">${l} (${n})</button>`).join('');
    const shown = all.filter(i => !catFilter || i.cat === catFilter);
    return `${bar}<div class="chips">${chips}</div><div class="grid">${shown.map(i => tile(i, 'itemEdit')).join('')}</div>`;
  }

  function editItem(i) {
    cutSrc = i && Photos.get(i.id) && !UI.isPng(Photos.get(i.id)) ? Photos.get(i.id) : null;
    const extra = `<div class="card cutbox"><b>✂️ إزالة الخلفية</b>
      <div class="muted">تعمل جيداً عندما تكون الخلفية موحدة (جدار، أرضية، سرير). إن بقيت بقايا ارفعي القوة، وإن اختفت أجزاء من القطعة اخفضيها.</div>
      <label>القوة<input type="range" id="cut_tol" min="0" max="100" value="35"></label>
      <div class="btns"><button class="btn sm ghost" data-act="itemCut">إزالة الخلفية</button>
      <button class="btn sm ghost" data-act="itemCutUndo">↩ الصورة الأصلية</button></div></div>`;
    UI.form(i ? 'تعديل القطعة' : 'قطعة جديدة', [
      { k: 'photo', label: 'الصورة', type: 'photo', value: i ? Photos.get(i.id) : '' },
      { k: 'name', label: 'الاسم', value: i && i.name, req: true, ph: 'مثال: بلوزة بيضاء قطن' },
      { k: 'cat', label: 'النوع', type: 'select', value: i ? i.cat : 'top', options: Object.entries(CATS).map(([k, v]) => [k, v[0]]) },
      { k: 'color', label: 'اللون', type: 'select', value: i ? i.color : 'أسود', options: Object.keys(COLORS).map(c => [c, c]) },
      { k: 'season', label: 'الموسم', type: 'select', value: i ? i.season : '', options: [['', 'كل المواسم']].concat(SEASONS.map(s => [s, s])) },
      { k: 'occ', label: 'المناسبة', type: 'select', value: i ? i.occ : '', options: [['', 'أي مناسبة']].concat(OCCS.map(o => [o, o])) },
      { k: 'price', label: 'السعر (اختياري، لحساب تكلفة اللبسة)', type: 'number', value: i && i.price }
    ], {
      extra,
      async onPhoto(k, data) {            // صورة جديدة: نقترح اللون تلقائياً
        cutSrc = data;
        try { $('#f_color').value = Cut.dominantColor(await Cut.canvasFromData(data)); } catch (e) {}
      },
      onSave(v) {
        const photo = v.photo; delete v.photo;
        v.price = v.price > 0 ? v.price : '';
        let target = i;
        if (i) Object.assign(i, v);
        else { target = Object.assign({ id: Store.uid() }, v); items().push(target); }
        if (photo && photo !== Photos.get(target.id)) Photos.set(target.id, photo);
        Store.save(); App.render();
      },
      onDelete: i && (() => {
        Store.d.items = items().filter(x => x.id !== i.id);
        looks().forEach(l => { l.items = l.items.filter(x => x !== i.id); });   // نزيلها من الإطلالات
        worn().forEach(w => { w.items = w.items.filter(x => x !== i.id); });
        Store.d.worn = worn().filter(w => w.items.length);
        Photos.del(i.id); Store.save(); App.render();
      })
    });
  }

  Actions.itemCut = async () => {
    if (!cutSrc) return UI.toast('الصورة الأصلية غير متوفرة. ارفعي صورة جديدة للقطعة.');
    UI.toast('جاري إزالة الخلفية...');
    await new Promise(r => setTimeout(r, 30));
    try {
      const res = Cut.removeBackground(await Cut.canvasFromData(cutSrc), +$('#cut_tol').value);
      if (res.error) return UI.toast(res.error);
      UI.setFormPhoto('photo', res.canvas.toDataURL('image/png'));
      $('#f_color').value = Cut.dominantColor(res.canvas);
      UI.toast('تمت إزالة الخلفية ✓');
    } catch (e) { UI.toast('تعذرت المعالجة'); }
  };
  Actions.itemCutUndo = () => {
    if (!cutSrc) return UI.toast('لا توجد صورة أصلية');
    UI.setFormPhoto('photo', cutSrc);
  };

  /* ---------- رفع عدة صور ---------- */
  Actions.outBatch = () => UI.pickFiles(true, async files => {
    if (files.length > 30) { UI.toast('اخترتِ ' + files.length + ' صورة، سأعالج أول 30'); files = files.slice(0, 30); }
    const list = [];
    for (let k = 0; k < files.length; k++) {
      UI.toast('جاري تجهيز الصور ' + (k + 1) + '/' + files.length);
      try {
        const c = await UI.fileToCanvas(files[k], 640);
        list.push({ tid: 'b' + k + Store.uid(), canvas: c, orig: c.toDataURL('image/jpeg', 0.78), photo: null, color: Cut.dominantColor(c), cut: false });
        list[list.length - 1].photo = list[list.length - 1].orig;
      } catch (e) { /* نتجاوز الصورة التالفة */ }
    }
    if (!list.length) return UI.toast('تعذر قراءة الصور');
    batch = { list };
    batchSheet();
  });

  function batchSheet() {
    const cat0 = catFilter || 'top';
    UI.sheet(`<h2>مراجعة ${batch.list.length} قطعة</h2>
      <p class="muted">اقترح التطبيق اللون تلقائياً، عدّلي ما يلزم وأضيفي الاسم والنوع.</p>
      <div class="btns" style="margin:0 0 12px"><button class="btn sm ghost" data-act="batchCutAll">✂️ إزالة الخلفية للكل</button></div>` +
      batch.list.map(b => `<div class="card batch" data-tid="${b.tid}">
        <div class="bt"><div class="ph sm" id="bp_${b.tid}" style="${UI.bgStyle(b.photo)}"></div>
        <div class="grow">
          <input class="b-name" placeholder="اسم القطعة (اختياري)">
          <div class="two"><select class="b-cat">${catOptions(cat0)}</select><select class="b-color">${colorOptions(b.color)}</select></div>
          <div class="two"><label class="chk"><input type="checkbox" class="b-cut" data-chg="batchCut" data-tid="${b.tid}"> إزالة الخلفية</label>
            <button class="chip" data-act="batchDel" data-tid="${b.tid}">حذف</button></div>
        </div></div></div>`).join('') +
      `<div class="btns"><button class="btn" data-act="batchSave">حفظ الكل</button></div>`);
  }

  async function applyCut(b, on) {
    const card = document.querySelector(`.batch[data-tid="${b.tid}"]`);
    const chk = card && card.querySelector('.b-cut'), colorSel = card && card.querySelector('.b-color');
    await new Promise(r => setTimeout(r, 20));
    if (on) {
      const res = Cut.removeBackground(b.canvas, 35);
      if (res.error) { UI.toast(res.error); if (chk) chk.checked = false; return false; }
      b.photo = res.canvas.toDataURL('image/png'); b.cut = true;
      b.color = Cut.dominantColor(res.canvas);
    } else {
      b.photo = b.orig; b.cut = false; b.color = Cut.dominantColor(b.canvas);
    }
    if (chk) chk.checked = b.cut;
    if (colorSel) colorSel.value = b.color;
    const p = document.getElementById('bp_' + b.tid); if (p) p.setAttribute('style', UI.bgStyle(b.photo));
    return true;
  }
  Actions.batchCut = el => { const b = batch.list.find(x => x.tid === el.dataset.tid); if (b) applyCut(b, el.checked); };
  Actions.batchCutAll = async () => {
    let n = 0;
    for (const b of batch.list) { if (!b.cut) { UI.toast('إزالة الخلفية ' + (++n) + '/' + batch.list.filter(x => !x.cut).length + '...'); await applyCut(b, true); } }
    UI.toast('انتهت المعالجة. راجعي الصور وألغي الإزالة لأي صورة لم تعجبك');
  };
  Actions.batchDel = el => {
    batch.list = batch.list.filter(x => x.tid !== el.dataset.tid);
    const c = document.querySelector(`.batch[data-tid="${el.dataset.tid}"]`); if (c) c.remove();
    if (!batch.list.length) UI.close();
  };
  Actions.batchSave = () => {
    let n = 0;
    batch.list.forEach(b => {
      const card = document.querySelector(`.batch[data-tid="${b.tid}"]`); if (!card) return;
      const cat = card.querySelector('.b-cat').value, color = card.querySelector('.b-color').value;
      const name = card.querySelector('.b-name').value.trim() || (CATS[cat][0] + ' ' + (items().length + 1));
      const it = { id: Store.uid(), name, cat, color, season: '', occ: '', price: '' };
      items().push(it); Photos.set(it.id, b.photo); n++;
    });
    batch = null; sub = 'closet'; catFilter = '';
    Store.save(); UI.close(); App.render();
    UI.toast('تمت إضافة ' + n + ' قطعة');
  };

  /* ======================= الإطلالات وسجل اللبس ======================= */
  function lastWorn(lookId) {
    const w = worn().filter(x => x.look === lookId).map(x => x.date).sort().pop();
    if (!w) return 'لم تُلبس بعد';
    const n = -UI.diffDays(w, UI.iso());
    return n === 0 ? 'لُبست اليوم' : 'آخر لبس: قبل ' + n + ' يوم';
  }

  function wornCard(w) {
    const its = w.items.map(item).filter(Boolean), lk = w.look ? look(w.look) : null;
    return `<div class="card" data-act="wornEdit" data-id="${w.id}">
      <div class="look-h"><b>${UI.fmtDate(w.date)}</b><span class="muted">${lk ? esc(lk.name) : ''} ✎</span></div>
      <div class="mini">${its.map(i => ph(i)).join('')}</div></div>`;
  }

  function looksView() {
    const top = `<div class="btns" style="margin:0 0 12px">
      <button class="btn sm" data-act="designNew">🎨 مصمم اللوحة</button>
      <button class="btn sm ghost" data-act="wornNew">＋ تسجيل لبس يوم</button></div>`;
    const ls = looks().map(l => {
      const its = l.items.map(item).filter(Boolean), img = Photos.get('L' + l.id);
      return `<div class="card">
        <div class="look-h"><b>${esc(l.name)}</b><span class="muted">${esc(l.occ || '')}</span></div>
        <div class="muted">${lastWorn(l.id)}</div>
        ${img ? `<img class="lookimg" src="${img}" alt="">` : `<div class="mini">${its.map(i => ph(i)).join('')}</div>`}
        <div class="btns"><button class="btn sm" data-act="lookWear" data-id="${l.id}">ألبستها اليوم</button>
          <button class="btn sm ghost" data-act="lookEdit" data-id="${l.id}">تعديل</button>
          <button class="btn sm ghost" data-act="lookDesign" data-id="${l.id}">${img ? '🎨 تعديل التصميم' : '🎨 تصميم'}</button></div></div>`;
    }).join('');
    const log = worn().slice().sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0);
    const shown = wornAll ? log : log.slice(0, 7);
    const logHtml = log.length
      ? `<h3 class="sec">آخر ما لبستيه</h3><p class="muted" style="margin-top:-4px">اضغطي على أي يوم لتعديل القطع.</p>${shown.map(wornCard).join('')}` +
        (log.length > 7 ? `<button class="btn ghost" data-act="wornMore">${wornAll ? 'عرض أقل' : 'عرض الكل (' + log.length + ')'}</button>` : '')
      : '';
    return top + (ls || '<div class="empty">لا توجد إطلالات محفوظة<br>صمّمي إطلالة على اللوحة، أو اضغطي + لتكوين إطلالة سريعة، أو جرّبي تبويب «اقتراح»</div>') + logHtml;
  }

  /* ----- تعديل / إضافة سجل لبس ----- */
  function wornSheet(w) {
    we = { id: w && w.id, sel: new Set(w ? w.items : []), cat: '' };
    if (!items().length) return UI.toast('أضيفي قطعاً إلى الخزانة أولاً');
    UI.sheet(`<h2>${w ? 'تعديل ما لبستيه' : 'تسجيل لبس يوم'}</h2>
      <label>التاريخ<input type="date" id="w_date" value="${w ? w.date : UI.iso()}"></label>
      <div class="chips" id="w_chips"></div><div class="grid" id="w_grid"></div>
      <div class="muted" id="w_cnt" style="margin-top:8px"></div>
      <div class="btns"><button class="btn" data-act="wornSave">حفظ</button>${w ? '<button class="btn danger" data-act="wornDel">حذف</button>' : ''}</div>`);
    wornGrid();
  }
  function wornGrid() {
    const all = items();
    $('#w_chips').innerHTML = [['', 'الكل']].concat(Object.entries(CATS).map(([k, v]) => [k, v[0]]))
      .filter(([k]) => k === '' || all.some(i => i.cat === k))
      .map(([k, l]) => `<button class="chip ${we.cat === k ? 'on' : ''}" data-act="wornCat" data-v="${k}">${l}</button>`).join('');
    $('#w_grid').innerHTML = all.filter(i => !we.cat || i.cat === we.cat).map(i => tile(i, 'wornPick', we.sel.has(i.id) ? 'sel' : '')).join('');
    $('#w_cnt').textContent = 'المحدد: ' + we.sel.size + ' قطعة';
  }
  Actions.wornCat = el => { we.cat = el.dataset.v; wornGrid(); };
  Actions.wornPick = el => {
    const id = el.dataset.id;
    if (we.sel.has(id)) we.sel.delete(id); else we.sel.add(id);
    el.classList.toggle('sel'); $('#w_cnt').textContent = 'المحدد: ' + we.sel.size + ' قطعة';
  };
  Actions.wornSave = () => {
    const date = $('#w_date').value;
    if (!date) return UI.toast('اختاري التاريخ');
    if (!we.sel.size) return UI.toast('اختاري قطعة واحدة على الأقل');
    const other = worn().find(x => x.date === date && x.id !== we.id);
    if (other && !confirm('يوجد تسجيل لهذا اليوم سيُستبدل به. متابعة؟')) return;
    const ids = [...we.sel];
    const same = looks().find(l => l.items.length === ids.length && l.items.every(x => we.sel.has(x)));
    Store.d.worn = worn().filter(x => x !== other && x.id !== we.id);
    worn().push({ id: we.id || Store.uid(), date, look: same ? same.id : null, items: ids });
    Store.save(); UI.close(); App.render();
  };
  Actions.wornDel = () => {
    if (!confirm('حذف هذا السجل؟')) return;
    Store.d.worn = worn().filter(x => x.id !== we.id);
    Store.save(); UI.close(); App.render();
  };
  Actions.wornEdit = el => wornSheet(worn().find(x => x.id === el.dataset.id));
  Actions.wornNew = () => wornSheet(null);
  Actions.wornMore = () => { wornAll = !wornAll; App.render(); };

  /* ----- إطلالة سريعة بالاختيار ----- */
  function lookSheet(l) {
    if (!items().length) return UI.toast('أضيفي قطعاً إلى الخزانة أولاً');
    ed = { id: l && l.id, sel: new Set(l ? l.items : []) };
    UI.sheet(`<h2>${l ? 'تعديل الإطلالة' : 'إطلالة جديدة'}</h2>
      <label>الاسم<input id="l_name" value="${esc(l ? l.name : '')}" placeholder="مثال: جامعة بسيطة"></label>
      <label>المناسبة<select id="l_occ"><option value="">أي مناسبة</option>${OCCS.map(o => `<option ${l && l.occ === o ? 'selected' : ''}>${o}</option>`).join('')}</select></label>
      <div class="muted" style="margin-bottom:8px">اختاري القطع:</div>
      <div class="grid">${items().map(i => tile(i, 'lookPick', ed.sel.has(i.id) ? 'sel' : '')).join('')}</div>
      <div class="btns"><button class="btn" data-act="lookSave">حفظ</button>${l ? '<button class="btn danger" data-act="lookDel">حذف</button>' : ''}</div>`);
  }

  function wear(ids, lookId) {
    const today = UI.iso();
    Store.d.worn = worn().filter(w => w.date !== today);   // إطلالة واحدة لكل يوم
    worn().push({ id: Store.uid(), date: today, look: lookId || null, items: ids });
    Store.save(); UI.toast('تم تسجيل إطلالة اليوم ✓'); App.render();
  }

  /* ======================= الاقتراح التلقائي ======================= */
  function pairScore(a, b) {
    if (NEUTRAL.includes(a) || NEUTRAL.includes(b)) return 2;     // المحايد يناسب الكل
    if (a === b) return 1;
    return FRIENDS.some(p => p.includes(a) && p.includes(b)) ? 1 : -2;
  }
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];

  function suggest() {
    const ok = i => (!sg.occ || !i.occ || i.occ === sg.occ) && (!sg.season || !i.season || i.season === sg.season);
    const pool = items().filter(ok), by = c => pool.filter(i => i.cat === c);
    const tops = by('top'), bottoms = by('bottom'), dresses = by('dress'), outers = by('outer'), shoes = by('shoes'), bags = by('bag'), accs = by('acc');
    if (!dresses.length && !(tops.length && bottoms.length)) {
      sg.result = null; sg.msg = 'لا تكفي القطع لهذه المناسبة والموسم. أضيفي علوي + سفلي (أو فستان).'; return;
    }
    // ما لُبس آخر 3 أيام نقلّل احتمال تكراره
    const recent = new Set();
    worn().filter(w => UI.diffDays(UI.iso(), w.date) <= 3).forEach(w => w.items.forEach(x => recent.add(x)));

    const cands = [];
    for (let n = 0; n < 80; n++) {
      const set = [];
      if (dresses.length && (!(tops.length && bottoms.length) || Math.random() < 0.4)) set.push(pick(dresses));
      else set.push(pick(tops), pick(bottoms));
      if (outers.length && (sg.season === 'شتاء' || Math.random() < 0.3)) set.push(pick(outers));
      if (shoes.length) set.push(pick(shoes));
      if (bags.length && Math.random() < 0.5) set.push(pick(bags));
      if (accs.length && Math.random() < 0.4) set.push(pick(accs));
      let score = Math.random() * 1.5;
      for (let a = 0; a < set.length; a++) {
        if (recent.has(set[a].id)) score -= 3;
        for (let b = a + 1; b < set.length; b++) score += pairScore(set[a].color, set[b].color);
      }
      cands.push({ ids: set.map(i => i.id), score });
    }
    const key = a => a.slice().sort().join();
    const old = sg.result ? key(sg.result) : '';
    const best = cands.sort((a, b) => b.score - a.score).filter(c => key(c.ids) !== old).slice(0, 5);
    sg.result = pick(best).ids; sg.msg = '';
  }

  function suggestView() {
    const opt = (arr, cur, blank) => `<option value="">${blank}</option>` + arr.map(x => `<option ${x === cur ? 'selected' : ''}>${x}</option>`).join('');
    const controls = `<div class="card">
      <label>المناسبة<select data-chg="sgOcc">${opt(OCCS, sg.occ, 'أي مناسبة')}</select></label>
      <label style="margin:0">الموسم<select data-chg="sgSeason">${opt(SEASONS, sg.season, 'كل المواسم')}</select></label></div>`;
    let res = '';
    if (sg.msg) res = `<div class="banner">${sg.msg}</div>`;
    else if (sg.result) {
      res = `<div class="card"><b>اقتراحي لك</b><div class="grid" style="margin-top:10px">${sg.result.map(id => item(id)).filter(Boolean).map(i => tile(i, 'noop')).join('')}</div>
        <div class="btns"><button class="btn sm" data-act="sgWear">ألبسها اليوم</button>
        <button class="btn sm ghost" data-act="sgSave">حفظ كإطلالة</button>
        <button class="btn sm ghost" data-act="sgDesign">🎨 ترتيبها على لوحة</button></div></div>`;
    }
    return controls + res + `<button class="btn" data-act="sgGo">${sg.result ? 'اقتراح آخر 🔄' : 'اقترحي لي إطلالة ✨'}</button>
      <p class="muted">التنسيق يعتمد على توافق الألوان، ويتجنب ما لبستيه في آخر 3 أيام.</p>`;
  }

  /* ======================= الإحصائيات ======================= */
  function statsView() {
    if (!items().length) return '<div class="empty">أضيفي قطعاً إلى الخزانة لتظهر الإحصائيات 📊</div>';
    const counts = {}, last = {};
    worn().forEach(w => w.items.forEach(id => {
      counts[id] = (counts[id] || 0) + 1;
      if (!last[id] || w.date > last[id]) last[id] = w.date;
    }));
    const days = worn().length, first = worn().map(w => w.date).sort()[0];
    const head = `<div class="card"><b>سجل اللبس</b><div class="muted">${days
      ? 'سجّلتِ ' + days + ' يوماً منذ ' + UI.fmtShort(first) + (days < 14 ? '. ما زال السجل قصيراً، وستصبح الأرقام أدق مع الوقت.' : '.')
      : 'لم تسجّلي أي يوم بعد. سجّلي لبسك من تبويب «الإطلالات» (زر تسجيل لبس يوم) أو «ألبستها اليوم» لتظهر الإحصائيات.'}</div></div>`;

    const topList = items().filter(i => counts[i.id]).sort((a, b) => counts[b.id] - counts[a.id]).slice(0, 6);
    const topHtml = topList.length ? `<h3 class="sec">الأكثر لبساً</h3>` + topList.map(i => {
      const cpw = i.price > 0 ? ` · تكلفة اللبسة ${UI.money(i.price / counts[i.id])}` : '';
      return `<div class="card tx" data-act="itemEdit" data-id="${i.id}"><div style="width:52px">${ph(i)}</div>
        <div class="grow"><div class="t-title">${esc(i.name)}</div><div class="meta">لُبست ${counts[i.id]} مرة${cpw}</div></div></div>`;
    }).join('') : '';

    const never = items().filter(i => !counts[i.id]);
    const neverHtml = days && never.length ? `<h3 class="sec">لم تُلبس أبداً (${never.length})</h3><div class="grid">${never.map(i => tile(i, 'itemEdit')).join('')}</div>` : '';

    const idle = items().filter(i => counts[i.id] && UI.diffDays(UI.iso(), last[i.id]) > 60)
      .sort((a, b) => last[a.id] < last[b.id] ? -1 : 1);
    const idleHtml = idle.length ? `<h3 class="sec">لم تُلبس منذ أكثر من 60 يوماً</h3>` + idle.map(i =>
      `<div class="card tx" data-act="itemEdit" data-id="${i.id}"><div style="width:52px">${ph(i)}</div>
        <div class="grow"><div class="t-title">${esc(i.name)}</div><div class="meta">آخر لبس قبل ${UI.diffDays(UI.iso(), last[i.id])} يوم</div></div></div>`).join('') : '';

    return head + topHtml + neverHtml + idleHtml;
  }

  /* ======================= العرض الرئيسي ======================= */
  function render() {
    const tabs = [['closet', 'الخزانة'], ['looks', 'الإطلالات'], ['suggest', 'اقتراح'], ['stats', 'إحصائيات']]
      .map(([k, l]) => `<button class="${sub === k ? 'on' : ''}" data-act="outSub" data-v="${k}">${l}</button>`).join('');
    const body = { closet, looks: looksView, suggest: suggestView, stats: statsView }[sub]();
    return `<div class="seg">${tabs}</div>${body}`;
  }

  Actions.noop = () => {};
  Actions.outSub = el => { sub = el.dataset.v; App.render(); };
  Actions.outCat = el => { catFilter = el.dataset.v; App.render(); };
  Actions.itemEdit = el => editItem(item(el.dataset.id));
  Actions.lookEdit = el => lookSheet(look(el.dataset.id));
  Actions.lookPick = el => {
    const id = el.dataset.id;
    if (ed.sel.has(id)) ed.sel.delete(id); else ed.sel.add(id);
    el.classList.toggle('sel');
  };
  Actions.lookSave = () => {
    if (ed.sel.size < 2) return UI.toast('اختاري قطعتين على الأقل');
    const name = $('#l_name').value.trim() || 'إطلالة ' + (looks().length + 1);
    const data = { name, occ: $('#l_occ').value, items: [...ed.sel] };
    if (ed.id) Object.assign(look(ed.id), data); else looks().push(Object.assign({ id: Store.uid() }, data));
    Store.save(); UI.close(); App.render();
  };
  Actions.lookDel = () => {
    if (!confirm('حذف الإطلالة؟')) return;
    Store.d.looks = looks().filter(l => l.id !== ed.id);
    Photos.del('L' + ed.id);
    Store.save(); UI.close(); App.render();
  };
  Actions.lookWear = el => { const l = look(el.dataset.id); wear(l.items.filter(item), l.id); };
  Actions.lookDesign = el => Designer.open({ lookId: el.dataset.id });
  Actions.designNew = () => Designer.open({});
  Actions.sgOcc = el => { sg.occ = el.value; sg.result = null; sg.msg = ''; App.render(); };
  Actions.sgSeason = el => { sg.season = el.value; sg.result = null; sg.msg = ''; App.render(); };
  Actions.sgGo = () => { suggest(); App.render(); };
  Actions.sgWear = () => wear(sg.result, null);
  Actions.sgSave = () => {
    looks().push({ id: Store.uid(), name: 'إطلالة ' + (looks().length + 1), occ: sg.occ, items: sg.result.slice() });
    Store.save(); UI.toast('تم الحفظ في تبويب الإطلالات');
  };
  Actions.sgDesign = () => Designer.open({ itemIds: sg.result.slice() });

  return {
    title: 'الملابس', render,
    add: () => sub === 'looks' ? lookSheet(null) : (sub = 'closet', editItem(null)),
    COLORS, CATS, OCCS
  };
})();
