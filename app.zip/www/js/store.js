/* ============================================================
   store.js — تخزين البيانات (على الجوال فقط) + النسخ الاحتياطي
   - البيانات النصية في localStorage
   - صور الملابس في IndexedDB (مساحة أكبر)
   ============================================================ */

const Store = (() => {
  const KEY = 'myapp.v1';
  const defaults = () => ({
    tasks: [],    // المهام
    tx: [],       // المصاريف والدخل
    habits: [],   // العادات
    items: [],    // قطع الملابس
    looks: [],    // الإطلالات المحفوظة
    worn: [],     // سجل ما لبستيه
    meta: { currency: 'د.ل', lastBackup: null }
  });

  let d;
  function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
      d = Object.assign(defaults(), saved);
      d.meta = Object.assign(defaults().meta, saved.meta || {});
    } catch (e) { d = defaults(); }
  }
  load();

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(d)); }
    catch (e) { UI.toast('تعذر الحفظ: المساحة ممتلئة'); }
  }

  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  return {
    get d() { return d; },
    save, uid,
    replace(obj) { d = Object.assign(defaults(), obj); d.meta = Object.assign(defaults().meta, obj.meta || {}); save(); },
    hasData() { return d.tasks.length + d.tx.length + d.habits.length + d.items.length > 0; }
  };
})();

/* ---------- صور الملابس (IndexedDB) ---------- */
const Photos = (() => {
  const cache = {};   // نبقي الصور في الذاكرة ليكون العرض فورياً
  let db = null;

  function open() {
    if (db) return Promise.resolve(db);
    return new Promise((res, rej) => {
      const r = indexedDB.open('myapp-photos', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('p');
      r.onsuccess = () => { db = r.result; res(db); };
      r.onerror = () => rej(r.error);
    });
  }
  function run(mode, fn) {
    return open().then(d => new Promise((res, rej) => {
      const t = d.transaction('p', mode);
      const r = fn(t.objectStore('p'));
      t.oncomplete = () => res(r && r.result);
      t.onerror = () => rej(t.error);
    }));
  }

  return {
    cache,
    get: id => cache[id],
    async init() {
      try {
        const d = await open();
        await new Promise(res => {
          const s = d.transaction('p').objectStore('p');
          const keys = s.getAllKeys(), vals = s.getAll();
          s.transaction.oncomplete = () => {
            keys.result.forEach((k, i) => { cache[k] = vals.result[i]; });
            res();
          };
        });
      } catch (e) { /* لو فشل نكمل بدون صور محفوظة */ }
    },
    set(id, data) { cache[id] = data; return run('readwrite', s => s.put(data, id)).catch(() => {}); },
    del(id) { delete cache[id]; return run('readwrite', s => s.delete(id)).catch(() => {}); },
    async clear() {
      Object.keys(cache).forEach(k => delete cache[k]);
      await run('readwrite', s => s.clear()).catch(() => {});
    }
  };
})();

/* ---------- النسخ الاحتياطي والاستعادة ---------- */
const Backup = {
  daysSince() {
    const t = Store.d.meta.lastBackup;
    return t ? Math.floor((Date.now() - t) / 864e5) : null;
  },

  // يحفظ ملفاً ويفتح قائمة المشاركة لتختاري Google Drive
  async export() {
    const json = JSON.stringify({
      app: 'myapp', v: 1, date: new Date().toISOString(),
      data: Store.d, photos: Photos.cache
    });
    const name = 'backup-' + UI.iso() + '.json';
    const C = window.Capacitor, P = C && C.Plugins;
    try {
      if (C && C.isNativePlatform && C.isNativePlatform() && P && P.Filesystem && P.Share) {
        const r = await P.Filesystem.writeFile({ path: name, data: json, directory: 'CACHE', encoding: 'utf8' });
        await P.Share.share({ title: 'نسخة احتياطية', url: r.uri, dialogTitle: 'احفظي النسخة في Google Drive' });
      } else {
        // وضع المتصفح (للتجربة على اللابتوب)
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
        a.download = name; a.click();
      }
      Store.d.meta.lastBackup = Date.now();
      Store.save();
      UI.toast('تم إنشاء النسخة الاحتياطية');
    } catch (e) {
      if (!/cancel/i.test(String(e && e.message))) UI.toast('تعذر إنشاء النسخة');
    }
  },

  async restore(file) {
    try {
      const obj = JSON.parse(await file.text());
      if (obj.app !== 'myapp' || !obj.data) throw new Error('bad');
      if (!confirm('ستُستبدل كل بياناتك الحالية بالنسخة المختارة. متأكدة؟')) return;
      await Photos.clear();
      for (const [k, v] of Object.entries(obj.photos || {})) await Photos.set(k, v);
      Store.replace(obj.data);
      UI.close();
      App.render();
      UI.toast('تمت الاستعادة بنجاح');
    } catch (e) { UI.toast('الملف غير صالح'); }
  }
};
