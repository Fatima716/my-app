/* ============================================================
   sync.js — المزامنة مع حسابك على Google عبر Firebase
   - تسجيل الدخول بحساب Google
   - تُحفظ بياناتك وصورك في قاعدة Firestore تحت حسابك فقط
   - يعمل تلقائياً: أي تعديل يُرفع بعد ثوانٍ، وعند فتح التطبيق على جهاز آخر تعود بياناتك
   - يحتاج إعداد Firebase مرة واحدة (انظري دليل الإعداد)، وقبل ذلك يظهر زر الربط معطّلاً

   مخطط البيانات في Firestore:
     users/{uid}/sync/meta     ← {rev, chunks:{مفتاح: عدد القطع}, device, at}
     users/{uid}/sync/photos   ← {sigs:{معرّف الصورة: بصمتها}}
     users/{uid}/data/{key}_{n}← {text}   (البيانات نصاً مقسّماً لقطع أقل من 1MB)
     users/{uid}/photos/{id}   ← {data}   (كل صورة في وثيقة مستقلة)
   ============================================================ */

const Sync = (() => {
  const SKEY = 'myapp.sync';
  const CHUNK = 200000;                      // حرف لكل قطعة (حد Firestore: 1MB للوثيقة)

  /* ---------- المحوّل الحقيقي: إضافات Capacitor Firebase ---------- */
  const FirebaseCloud = {
    P() { return window.Capacitor && window.Capacitor.Plugins || {}; },
    available() {
      const C = window.Capacitor, P = this.P();
      return !!(C && C.isNativePlatform && C.isNativePlatform() && P.FirebaseAuthentication && P.FirebaseFirestore);
    },
    async user() {
      const r = await this.P().FirebaseAuthentication.getCurrentUser();
      return r && r.user ? { uid: r.user.uid, email: r.user.email || '' } : null;
    },
    async signIn() {
      const r = await this.P().FirebaseAuthentication.signInWithGoogle();
      if (!r || !r.user) throw new Error('لم يُرجع الدخول مستخدماً');
      return { uid: r.user.uid, email: r.user.email || '' };
    },
    async signOut() { await this.P().FirebaseAuthentication.signOut(); },
    async get(path) {
      const r = await this.P().FirebaseFirestore.getDocument({ reference: path });
      return r && r.snapshot && r.snapshot.data ? r.snapshot.data : null;
    },
    async set(path, data) { await this.P().FirebaseFirestore.setDocument({ reference: path, data }); },
    async del(path) { await this.P().FirebaseFirestore.deleteDocument({ reference: path }); }
  };
  const cloud = () => window.__CLOUD_TEST__ || FirebaseCloud;   // __CLOUD_TEST__ للاختبار فقط

  /* ---------- الحالة المحلية ---------- */
  const fresh = () => ({ uid: null, email: '', rev: null, dirty: false, putQ: [], delQ: [], last: null, err: '' });
  function load() { try { return Object.assign(fresh(), JSON.parse(localStorage.getItem(SKEY) || '{}')); } catch (e) { return fresh(); } }
  let st = load();
  const persist = () => { try { localStorage.setItem(SKEY, JSON.stringify(st)); } catch (e) {} };
  let enabled = false, busy = false, timer = null, pending = null, working = '';

  const P = (uid, rest) => `users/${uid}/${rest}`;
  const sig = d => d.length + ':' + d.slice(-24);

  // نقسم النص دون شقّ زوج الرموز (الإيموجي) لأن الشق يفسد الحفظ بـ UTF-8
  function chunkText(text) {
    const out = []; let i = 0;
    while (i < text.length) {
      let end = Math.min(text.length, i + CHUNK);
      if (end < text.length) { const c = text.charCodeAt(end - 1); if (c >= 0xD800 && c <= 0xDBFF) end--; }
      out.push(text.slice(i, end)); i = end;
    }
    return out.length ? out : [''];
  }

  /* ---------- الرفع ---------- */
  async function push(uid, remote, all) {
    const C = cloud();
    const putQ = st.putQ.splice(0), delQ = st.delQ.splice(0);
    st.dirty = false;
    try {
      working = 'رفع البيانات...';
      const chunks = {};
      for (const k of Object.keys(Store.d)) {
        const parts = chunkText(JSON.stringify(Store.d[k]));
        chunks[k] = parts.length;
        for (let i = 0; i < parts.length; i++) await C.set(P(uid, `data/${k}_${i}`), { text: parts[i] });
        const old = remote && remote.chunks && remote.chunks[k] || 0;
        for (let i = parts.length; i < old; i++) await C.del(P(uid, `data/${k}_${i}`));
      }
      if (remote && remote.chunks) {            // مفاتيح حُذفت من التطبيق
        for (const k of Object.keys(remote.chunks)) if (!(k in chunks)) for (let i = 0; i < remote.chunks[k]; i++) await C.del(P(uid, `data/${k}_${i}`));
      }

      // الصور
      const idxDoc = await C.get(P(uid, 'sync/photos'));
      const sigs = Object.assign({}, idxDoc && idxDoc.sigs || {});
      const local = Photos.ids();
      const puts = all ? local : putQ.filter(id => Photos.get(id));
      const dels = all ? Object.keys(sigs).filter(id => !local.includes(id)) : delQ;
      let n = 0;
      for (const id of puts) {
        working = 'رفع الصور ' + (++n) + '/' + puts.length;
        const data = Photos.get(id); if (!data) continue;
        if (all && sigs[id] === sig(data)) continue;               // موجودة ومطابقة
        await C.set(P(uid, `photos/${id}`), { data }); sigs[id] = sig(data);
      }
      for (const id of dels) { await C.del(P(uid, `photos/${id}`)); delete sigs[id]; }
      await C.set(P(uid, 'sync/photos'), { sigs });

      const rev = Math.max(Date.now(), (remote && remote.rev || 0) + 1);
      await C.set(P(uid, 'sync/meta'), { rev, chunks, device: navigator.userAgent.slice(0, 60), at: new Date().toISOString() });
      st.uid = uid; st.rev = rev; st.last = Date.now();
    } catch (e) {
      st.dirty = true; st.putQ.unshift(...putQ); st.delQ.unshift(...delQ);
      throw e;
    }
  }

  /* ---------- التنزيل ---------- */
  async function pull(uid, remote) {
    const C = cloud();
    working = 'تنزيل البيانات...';
    const obj = {};
    for (const k of Object.keys(remote.chunks || {})) {
      let text = '';
      for (let i = 0; i < remote.chunks[k]; i++) {
        const d = await C.get(P(uid, `data/${k}_${i}`));
        if (!d) throw new Error('بيانات ناقصة في السحابة (' + k + ')');
        text += d.text;
      }
      obj[k] = JSON.parse(text);
    }
    const idx = await C.get(P(uid, 'sync/photos')), sigs = idx && idx.sigs || {};
    const ids = Object.keys(sigs); let n = 0;
    for (const id of ids) {
      const have = Photos.get(id);
      if (have && sig(have) === sigs[id]) continue;
      working = 'تنزيل الصور ' + (++n);
      const d = await C.get(P(uid, `photos/${id}`));
      if (d && d.data) await Photos.set(id, d.data, true);
    }
    for (const id of Photos.ids()) if (!(id in sigs)) await Photos.del(id, true);
    Store.replace(obj, true);
    st.uid = uid; st.rev = remote.rev; st.dirty = false; st.putQ = []; st.delQ = []; st.last = Date.now();
    App.render();
  }

  /* ---------- القرار: ماذا نفعل الآن؟ ---------- */
  async function syncNow(reason) {
    if (!enabled || busy) return;
    if (navigator.onLine === false) { st.err = 'لا يوجد إنترنت، ستتم المزامنة لاحقاً'; refresh(); return; }
    busy = true; st.err = ''; refresh();
    try {
      const C = cloud(), u = await C.user();
      if (!u) { enabled = false; st.err = 'انتهت جلسة الدخول، سجّلي الدخول مجدداً'; return; }
      const uid = u.uid;
      const remote = await C.get(P(uid, 'sync/meta'));
      const same = st.uid === uid && st.rev != null;
      if (!remote) await push(uid, null, true);                                   // السحابة فارغة: نرفع كل شيء
      else if (same && st.rev === remote.rev) { if (st.dirty) await push(uid, remote, false); }
      else if (same && !st.dirty) { await pull(uid, remote); if (reason !== 'start') UI.toast('تم تحديث بياناتك من السحابة'); }
      else if (Store.isEmpty() && !Photos.ids().length) await pull(uid, remote);   // جهاز جديد
      else { pending = { uid, remote }; conflictSheet(); }                        // بيانات في الجهتين
    } catch (e) {
      st.err = 'تعذرت المزامنة: ' + (e && e.message || e);
    } finally {
      busy = false; working = ''; persist(); refresh();
      if (st.dirty && enabled && !st.err && !pending) schedule(4000);            // تغييرات حدثت أثناء الرفع
    }
  }

  function conflictSheet() {
    UI.sheet(`<h2>أيّ البيانات نعتمد؟</h2>
      <p class="muted">وجدنا بيانات على هذا الجوال وبيانات أخرى محفوظة في حسابك على السحابة. اختاري ما تريدين الإبقاء عليه، والآخر سيُستبدل.</p>
      <div class="btns" style="flex-direction:column">
        <button class="btn" data-act="syncUseCloud">☁️ اعتماد بيانات السحابة</button>
        <button class="btn ghost" data-act="syncUseLocal">📱 اعتماد بيانات هذا الجوال</button>
        <button class="btn ghost" data-act="syncLater">لاحقاً</button></div>`);
  }

  function schedule(ms) { clearTimeout(timer); if (enabled) timer = setTimeout(() => syncNow('auto'), ms); }

  /* ---------- نقاط يستدعيها التطبيق ---------- */
  function touch() { if (!enabled) return; st.dirty = true; persist(); schedule(4000); }
  function photoPut(id) { if (!enabled) return; if (!st.putQ.includes(id)) st.putQ.push(id); st.delQ = st.delQ.filter(x => x !== id); st.dirty = true; persist(); schedule(4000); }
  function photoDel(id) { if (!enabled) return; if (!st.delQ.includes(id)) st.delQ.push(id); st.putQ = st.putQ.filter(x => x !== id); st.dirty = true; persist(); schedule(4000); }

  async function init() {
    document.addEventListener('visibilitychange', () => {
      if (!enabled) return;
      if (document.visibilityState === 'visible') syncNow('resume');
      else if (st.dirty) syncNow('hide');
    });
    window.addEventListener('online', () => syncNow('online'));
    try {
      if (!cloud().available()) return;
      const u = await cloud().user();
      if (u) { enabled = true; st.email = u.email; persist(); syncNow('start'); }
    } catch (e) { /* لا شيء */ }
  }

  /* ---------- واجهة الإعدادات ---------- */
  function ago(t) {
    if (!t) return 'لم تتم بعد';
    const m = Math.round((Date.now() - t) / 60000);
    return m < 1 ? 'الآن' : m < 60 ? 'قبل ' + m + ' دقيقة' : m < 1440 ? 'قبل ' + Math.round(m / 60) + ' ساعة' : 'قبل ' + Math.round(m / 1440) + ' يوم';
  }
  function settingsHtml() {
    if (!cloud().available()) {
      return `<div class="banner">☁️ المزامنة مع حساب Google غير مفعّلة بعد في هذه النسخة. تحتاج إعداد Firebase مرة واحدة (الخطوات في ملف الدليل)، وبعدها يظهر هنا زر تسجيل الدخول تلقائياً. إلى ذلك الحين استخدمي النسخة الاحتياطية بالملف.</div>`;
    }
    if (!enabled) {
      return `<p class="muted">سجّلي الدخول بحساب Google لتُحفظ بياناتك وصورك تلقائياً، وتعود إليك عند تغيير الهاتف.</p>
        <button class="btn" data-act="syncSignIn">🔐 تسجيل الدخول بحساب Google</button>
        ${st.err ? `<p class="late">${UI.esc(st.err)}</p>` : ''}`;
    }
    const state = busy ? ('⏳ ' + (working || 'جارٍ المزامنة...')) : st.err ? '⚠️ ' + UI.esc(st.err) : st.dirty ? '⏳ بانتظار الرفع' : '✅ كل بياناتك محفوظة في السحابة';
    return `<div class="card"><b>${UI.esc(st.email || 'حساب Google')}</b>
        <div class="muted">${state}</div><div class="muted">آخر مزامنة: ${ago(st.last)}</div></div>
      <div class="btns"><button class="btn sm" data-act="syncNowBtn">🔄 مزامنة الآن</button>
        <button class="btn sm ghost" data-act="syncSignOut">تسجيل الخروج</button></div>`;
  }
  function refresh() { if (document.getElementById('s_cur') && typeof App !== "undefined") App.settings(); }   // نحدّث نافذة الإعدادات إن كانت مفتوحة

  Actions.syncSignIn = async () => {
    try {
      const u = await cloud().signIn();
      enabled = true; st.email = u.email; persist();
      UI.toast('تم تسجيل الدخول');
      syncNow('login');
    } catch (e) { UI.toast('تعذر تسجيل الدخول: ' + (e && e.message || e)); }
  };
  Actions.syncSignOut = async () => {
    if (!confirm('تسجيل الخروج؟ تبقى بياناتك على هذا الجوال، لكن لن تُزامَن حتى تسجلي الدخول مجدداً.')) return;
    try { await cloud().signOut(); } catch (e) {}
    enabled = false; st = fresh(); persist(); clearTimeout(timer); refresh();
  };
  Actions.syncNowBtn = () => syncNow('manual');
  Actions.syncUseCloud = async () => {
    const p = pending; pending = null; UI.close(); if (!p) return;
    busy = true; refresh();
    try { await pull(p.uid, p.remote); UI.toast('تم اعتماد بيانات السحابة'); }
    catch (e) { st.err = 'تعذرت المزامنة: ' + (e && e.message || e); }
    busy = false; working = ''; persist(); refresh();
  };
  Actions.syncUseLocal = async () => {
    const p = pending; pending = null; UI.close(); if (!p) return;
    busy = true; refresh();
    try { await push(p.uid, p.remote, true); UI.toast('تم رفع بيانات الجوال'); }
    catch (e) { st.err = 'تعذرت المزامنة: ' + (e && e.message || e); }
    busy = false; working = ''; persist(); refresh();
  };
  Actions.syncLater = () => { pending = null; UI.close(); };

  return { init, touch, photoPut, photoDel, settingsHtml, syncNow, state: () => ({ enabled, busy, st }) };
})();
