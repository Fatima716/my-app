/* ============================================================
   tasks.js — مدير المهام
   ============================================================ */

const Tasks = (() => {
  let filter = 'today';

  const PRI = { h: ['عالية', 'var(--red)'], m: ['متوسطة', 'var(--amber)'], l: ['منخفضة', 'var(--green)'] };
  const CATS = ['شخصي', 'دراسة', 'أبحاث/عمل', 'بيت', 'صحة', 'أخرى'];
  const REPEAT = [['', 'بدون تكرار'], ['d', 'يومياً'], ['w', 'أسبوعياً'], ['m', 'شهرياً']];
  const FILTERS = [['today', 'اليوم'], ['upcoming', 'القادمة'], ['all', 'كل المفتوحة'], ['done', 'المنجزة']];

  const list = () => Store.d.tasks;
  const find = id => list().find(t => t.id === id);

  function match(t, f) {
    const today = UI.iso();
    if (f === 'done') return t.done;
    if (t.done) return false;
    if (f === 'today') return t.due && t.due <= today;
    if (f === 'upcoming') return t.due && t.due > today;
    return true;
  }

  // ترتيب: الأقرب موعداً ثم الأعلى أولوية
  function sorter(a, b) {
    const ad = a.due || '9999', bd = b.due || '9999';
    if (ad !== bd) return ad < bd ? -1 : 1;
    return 'hml'.indexOf(a.pri) - 'hml'.indexOf(b.pri);
  }

  function nextDue(due, rep) {
    const today = UI.iso();
    const step = s => {
      const d = UI.parse(s);
      if (rep === 'd') d.setDate(d.getDate() + 1);
      else if (rep === 'w') d.setDate(d.getDate() + 7);
      else d.setMonth(d.getMonth() + 1);
      return UI.iso(d);
    };
    let n = step(due);
    for (let i = 0; i < 400 && n <= today; i++) n = step(n);
    return n;
  }

  function render() {
    const chips = FILTERS.map(([k, label]) => {
      const n = list().filter(t => match(t, k)).length;
      return `<button class="chip ${filter === k ? 'on' : ''}" data-act="taskFilter" data-v="${k}">${label}${k !== 'done' ? ' (' + n + ')' : ''}</button>`;
    }).join('');

    const items = list().filter(t => match(t, filter)).sort(sorter);
    const today = UI.iso();
    const rows = items.map(t => {
      const late = !t.done && t.due && t.due < today;
      const bits = [t.cat];
      if (t.due) bits.push(`<span class="${late ? 'late' : ''}">${late ? 'متأخرة · ' : ''}${UI.fmtDate(t.due)}</span>`);
      if (t.repeat) bits.push('🔁');
      return `<div class="card task ${t.done ? 'done' : ''}">
        <button class="check ${t.done ? 'on' : ''}" data-act="taskToggle" data-id="${t.id}" aria-label="إنجاز">✓</button>
        <div class="grow" data-act="taskEdit" data-id="${t.id}">
          <div class="t-title">${UI.esc(t.title)}</div>
          <div class="meta"><span class="dot" style="background:${PRI[t.pri][1]}"></span>${bits.join(' · ')}</div>
          ${t.note ? `<div class="meta">${UI.esc(t.note)}</div>` : ''}
        </div></div>`;
    }).join('');

    const emptyMsg = { today: 'لا توجد مهام لليوم 🎉<br>اضغطي + لإضافة مهمة', upcoming: 'لا توجد مهام قادمة', all: 'لا توجد مهام مفتوحة', done: 'لم تنجزي أي مهمة بعد' }[filter];
    return `<div class="chips">${chips}</div>${rows || `<div class="empty">${emptyMsg}</div>`}`;
  }

  function edit(t) {
    UI.form(t ? 'تعديل المهمة' : 'مهمة جديدة', [
      { k: 'title', label: 'المهمة', value: t && t.title, req: true },
      { k: 'due', label: 'الموعد', type: 'date', value: t ? t.due : UI.iso() },
      { k: 'pri', label: 'الأولوية', type: 'select', value: t ? t.pri : 'm', options: Object.entries(PRI).map(([k, v]) => [k, v[0]]) },
      { k: 'cat', label: 'التصنيف', type: 'select', value: t ? t.cat : 'شخصي', options: CATS.map(c => [c, c]) },
      { k: 'repeat', label: 'التكرار', type: 'select', value: t ? t.repeat : '', options: REPEAT },
      { k: 'note', label: 'ملاحظة', type: 'textarea', value: t && t.note }
    ], {
      onSave(v) {
        if (v.repeat && !v.due) { UI.toast('المهمة المتكررة تحتاج موعداً'); return false; }
        if (t) Object.assign(t, v);
        else list().push(Object.assign({ id: Store.uid(), done: false, created: Date.now() }, v));
        Store.save(); App.render();
      },
      onDelete: t && (() => { Store.d.tasks = list().filter(x => x.id !== t.id); Store.save(); App.render(); })
    });
  }

  Actions.taskFilter = el => { filter = el.dataset.v; App.render(); };
  Actions.taskEdit = el => edit(find(el.dataset.id));
  Actions.taskToggle = el => {
    const t = find(el.dataset.id);
    if (!t) return;
    if (!t.done && t.repeat && t.due) {          // المهمة المتكررة تنتقل للموعد القادم
      t.due = nextDue(t.due, t.repeat);
      UI.toast('تم ✓ الموعد القادم: ' + UI.fmtDate(t.due));
    } else {
      t.done = !t.done;
    }
    Store.save(); App.render();
  };

  return { title: 'المهام', render, add: () => edit(null) };
})();
