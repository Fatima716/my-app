/* ============================================================
   ui.js — أدوات مشتركة: تواريخ، نوافذ، نماذج، رسائل، صور
   ============================================================ */

const Actions = {};   // كل زر في التطبيق يستدعي دالة من هنا عبر data-act
const $ = s => document.querySelector(s);

const UI = (() => {
  const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const z = n => String(n).padStart(2, '0');

  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const iso = (d = new Date()) => d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const diffDays = (a, b) => Math.round((parse(a) - parse(b)) / 864e5);   // a - b

  function fmtDate(s) {
    if (!s) return '';
    const n = diffDays(s, iso());
    if (n === 0) return 'اليوم';
    if (n === 1) return 'غداً';
    if (n === -1) return 'أمس';
    const d = parse(s);
    return DAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()];
  }
  const fmtShort = s => { const d = parse(s); return d.getDate() + ' ' + MONTHS[d.getMonth()]; };
  // علامة LRM تمنع انقلاب إشارة الناقص إلى يمين الرقم في الواجهة العربية
  const money = n => (n < 0 ? '‎' : '') + Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 });

  /* ---- رسالة قصيرة ---- */
  let tt;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 2400);
  }

  /* ---- زر الرجوع في أندرويد: كل نافذة تسجّل دالة إغلاق في مكدس ---- */
  const backStack = []; let skip = 0, skipTimer;
  function pushBack(fn) { backStack.push(fn); history.pushState({ b: backStack.length }, ''); }
  function popBack(fn) {                       // إغلاق برمجي: نحذف الإدخال ونرجع خطوة بدون تشغيل الدالة
    const i = backStack.lastIndexOf(fn);
    if (i < 0) return;
    backStack.splice(i, 1); skip++; history.back();
    clearTimeout(skipTimer); skipTimer = setTimeout(() => { skip = 0; }, 1200);
  }
  window.addEventListener('popstate', () => {
    if (skip > 0) { skip--; return; }
    const fn = backStack.pop();
    if (fn) fn(true);                          // ضغط المستخدم زر الرجوع
  });

  /* ---- النافذة المنبثقة ---- */
  let isOpen = false;
  const sheetCloser = () => { isOpen = false; $('#sheet').classList.remove('open'); };
  function sheet(html) {
    $('#sheet-body').innerHTML = html;
    $('#sheet').classList.add('open');
    if (!isOpen) { isOpen = true; pushBack(sheetCloser); }
  }
  function close() {
    if (!isOpen) return;
    isOpen = false;
    $('#sheet').classList.remove('open');
    popBack(sheetCloser);
  }

  /* ---- الصور ---- */
  const isPng = d => typeof d === 'string' && d.startsWith('data:image/png');

  // نمط معاينة الصورة: الصور المقصوصة (PNG شفاف) تُعرض كاملة فوق مربعات الشفافية
  function bgStyle(d) {
    if (!d) return '';
    return isPng(d)
      ? `background:url('${d}') center/contain no-repeat, repeating-conic-gradient(#ececec 0% 25%, #fff 0% 50%) 50%/16px 16px`
      : `background:url('${d}') center/cover no-repeat`;
  }

  function loadImage(src) {
    return new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => res(img);
      img.onerror = () => rej(new Error('image'));
      img.src = src;
    });
  }

  // ملف صورة → لوحة (canvas) مصغّرة
  async function fileToCanvas(file, max = 640) {
    const url = URL.createObjectURL(file);
    try {
      const img = await loadImage(url);
      const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.naturalWidth * s)); c.height = Math.max(1, Math.round(img.naturalHeight * s));
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      return c;
    } finally { URL.revokeObjectURL(url); }
  }
  async function compress(file, max = 640) {
    return (await fileToCanvas(file, max)).toDataURL('image/jpeg', 0.78);
  }

  // يفتح نافذة اختيار صور من المعرض
  function pickFiles(multiple, cb) {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*'; inp.multiple = !!multiple;
    inp.onchange = () => { if (inp.files && inp.files.length) cb([...inp.files]); };
    inp.click();
  }

  // مشاركة / حفظ ملف (أندرويد: قائمة المشاركة، المتصفح: تنزيل)
  async function shareData(dataUrl, filename, title) {
    const C = window.Capacitor, P = C && C.Plugins;
    if (C && C.isNativePlatform && C.isNativePlatform() && P && P.Filesystem && P.Share) {
      const base64 = dataUrl.split(',')[1];
      const r = await P.Filesystem.writeFile({ path: filename, data: base64, directory: 'CACHE' });
      await P.Share.share({ title: title || filename, url: r.uri, dialogTitle: title || filename });
    } else {
      const a = document.createElement('a'); a.href = dataUrl; a.download = filename; a.click();
    }
  }

  /* ---- نموذج عام ----
     fields: [{k, label, type: text|number|date|select|textarea|photo, value, options, req, ph}]
     opts:   {onSave(values), onDelete(), after(), saveLabel, extra: html, onPhoto(k, data)}     */
  let F = null;
  function form(title, fields, opts = {}) {
    F = { fields, opts, photos: {} };
    const body = fields.map(f => {
      const id = 'f_' + f.k, v = f.value == null ? '' : f.value;
      let inp;
      if (f.type === 'select') {
        inp = `<select id="${id}">` + f.options.map(o =>
          `<option value="${esc(o[0])}" ${String(o[0]) === String(v) ? 'selected' : ''}>${esc(o[1])}</option>`).join('') + '</select>';
      } else if (f.type === 'textarea') {
        inp = `<textarea id="${id}" rows="3">${esc(v)}</textarea>`;
      } else if (f.type === 'photo') {
        F.photos[f.k] = v;
        inp = `<div class="pv" id="pv_${f.k}" style="${bgStyle(v)}">${v ? '' : '📷 اضغطي لإضافة صورة'}</div>` +
              `<input id="${id}" type="file" accept="image/*" data-chg="formPhoto" data-k="${f.k}">`;
      } else {
        inp = `<input id="${id}" type="${f.type || 'text'}" value="${esc(v)}"` +
              `${f.type === 'number' ? ' inputmode="decimal" step="any"' : ''}${f.ph ? ` placeholder="${esc(f.ph)}"` : ''}>`;
      }
      return `<label>${esc(f.label)}${inp}</label>`;
    }).join('');
    sheet(`<h2>${esc(title)}</h2>${body}${opts.extra || ''}<div class="btns">` +
      `<button class="btn" data-act="formSave">${opts.saveLabel || 'حفظ'}</button>` +
      (opts.onDelete ? '<button class="btn danger" data-act="formDel">حذف</button>' : '') + '</div>');
    if (opts.after) opts.after();
  }

  // يحدّث صورة النموذج برمجياً (مثلاً بعد إزالة الخلفية)
  function setFormPhoto(k, data) {
    F.photos[k] = data;
    const pv = document.getElementById('pv_' + k);
    if (pv) { pv.setAttribute('style', bgStyle(data)); pv.textContent = ''; }
  }
  const formPhoto = k => F.photos[k];

  function values() {
    const o = {};
    F.fields.forEach(f => {
      if (f.type === 'photo') { o[f.k] = F.photos[f.k]; return; }
      const el = document.getElementById('f_' + f.k);
      o[f.k] = f.type === 'number'
        ? (el.value === '' ? NaN : parseFloat(el.value.replace(',', '.')))
        : el.value.trim();
    });
    return o;
  }

  Actions.formSave = () => {
    const v = values();
    for (const f of F.fields) {
      if (f.req && (v[f.k] === '' || (typeof v[f.k] === 'number' && isNaN(v[f.k])) || v[f.k] == null)) {
        return toast('الرجاء تعبئة: ' + f.label);
      }
    }
    if (F.opts.onSave(v) !== false) close();
  };
  Actions.formDel = () => {
    if (confirm('تأكيد الحذف؟')) { F.opts.onDelete(); close(); }
  };
  Actions.closeSheet = () => close();

  Actions.formPhoto = async el => {
    const file = el.files && el.files[0];
    if (!file) return;
    try {
      const data = await compress(file);
      setFormPhoto(el.dataset.k, data);
      if (F.opts.onPhoto) F.opts.onPhoto(el.dataset.k, data);
    } catch (e) { toast('تعذر قراءة الصورة'); }
  };

  return { MONTHS, DAYS, esc, iso, parse, diffDays, fmtDate, fmtShort, money, toast, sheet, close, form, compress,
           isPng, bgStyle, loadImage, fileToCanvas, pickFiles, shareData, setFormPhoto, formPhoto, pushBack, popBack };
})();
