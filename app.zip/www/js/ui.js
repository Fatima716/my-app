/* ============================================================
   ui.js — أدوات مشتركة: تواريخ، نوافذ، نماذج، رسائل
   ============================================================ */

const Actions = {};   // كل زر في التطبيق يستدعي دالة من هنا عبر data-act
const $ = s => document.querySelector(s);

const UI = (() => {
  const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const z = n => String(n).padStart(2, '0');

  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const iso = (d = new Date()) => d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const diffDays = (a, b) => Math.round((parse(a) - parse(b)) / 864e5);   // a - b

  function fmtDate(s) {
    if (!s) return '';
    const n = diffDays(s, iso());
    if (n === 0) return 'اليوم';
    if (n === 1) return 'غداً';
    if (n === -1) return 'أمس';
    const d = parse(s);
    return DAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()];
  }
  const fmtShort = s => { const d = parse(s); return d.getDate() + ' ' + MONTHS[d.getMonth()]; };
  const money = n => Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 });

  /* ---- رسالة قصيرة ---- */
  let tt;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 2200);
  }

  /* ---- النافذة المنبثقة (مع دعم زر الرجوع في أندرويد) ---- */
  let isOpen = false, skipPop = false;
  function sheet(html) {
    $('#sheet-body').innerHTML = html;
    $('#sheet').classList.add('open');
    if (!isOpen) { isOpen = true; history.pushState({ s: 1 }, ''); }
  }
  function close() {
    if (!isOpen) return;
    isOpen = false;
    $('#sheet').classList.remove('open');
    if (history.state && history.state.s) { skipPop = true; history.back(); }
  }
  window.addEventListener('popstate', () => {
    if (skipPop) { skipPop = false; return; }
    if (isOpen) { isOpen = false; $('#sheet').classList.remove('open'); }
  });

  /* ---- نموذج عام ----
     fields: [{k, label, type: text|number|date|select|textarea|photo, value, options, req, ph}]
     opts:   {onSave(values), onDelete(), after(), saveLabel}                                  */
  let F = null;
  function form(title, fields, opts = {}) {
    F = { fields, opts, photos: {} };
    const body = fields.map(f => {
      const id = 'f_' + f.k, v = f.value == null ? '' : f.value;
      let inp;
      if (f.type === 'select') {
        inp = `<select id="${id}">` + f.options.map(o =>
          `<option value="${esc(o[0])}" ${String(o[0]) === String(v) ? 'selected' : ''}>${esc(o[1])}</option>`).join('') + '</select>';
      } else if (f.type === 'textarea') {
        inp = `<textarea id="${id}" rows="3">${esc(v)}</textarea>`;
      } else if (f.type === 'photo') {
        F.photos[f.k] = v;
        inp = `<div class="pv" id="pv_${f.k}" style="${v ? `background-image:url('${v}')` : ''}">${v ? '' : '📷 اضغطي لإضافة صورة'}</div>` +
              `<input id="${id}" type="file" accept="image/*" data-chg="formPhoto" data-k="${f.k}">`;
      } else {
        inp = `<input id="${id}" type="${f.type || 'text'}" value="${esc(v)}"` +
              `${f.type === 'number' ? ' inputmode="decimal" step="any"' : ''}${f.ph ? ` placeholder="${esc(f.ph)}"` : ''}>`;
      }
      return `<label>${esc(f.label)}${inp}</label>`;
    }).join('');
    sheet(`<h2>${esc(title)}</h2>${body}<div class="btns">` +
      `<button class="btn" data-act="formSave">${opts.saveLabel || 'حفظ'}</button>` +
      (opts.onDelete ? '<button class="btn danger" data-act="formDel">حذف</button>' : '') + '</div>');
    if (opts.after) opts.after();
  }

  function values() {
    const o = {};
    F.fields.forEach(f => {
      if (f.type === 'photo') { o[f.k] = F.photos[f.k]; return; }
      const el = document.getElementById('f_' + f.k);
      o[f.k] = f.type === 'number'
        ? (el.value === '' ? NaN : parseFloat(el.value.replace(',', '.')))
        : el.value.trim();
    });
    return o;
  }

  Actions.formSave = () => {
    const v = values();
    for (const f of F.fields) {
      if (f.req && (v[f.k] === '' || (typeof v[f.k] === 'number' && isNaN(v[f.k])) || v[f.k] == null)) {
        return toast('الرجاء تعبئة: ' + f.label);
      }
    }
    if (F.opts.onSave(v) !== false) close();
  };
  Actions.formDel = () => {
    if (confirm('تأكيد الحذف؟')) { F.opts.onDelete(); close(); }
  };
  Actions.closeSheet = () => close();

  // ضغط الصورة قبل حفظها حتى لا تمتلئ المساحة
  function compress(file, max = 640) {
    return new Promise((res, rej) => {
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        const s = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        res(c.toDataURL('image/jpeg', 0.78));
      };
      img.onerror = rej;
      img.src = url;
    });
  }
  Actions.formPhoto = async el => {
    const file = el.files && el.files[0];
    if (!file) return;
    try {
      const data = await compress(file);
      F.photos[el.dataset.k] = data;
      const pv = document.getElementById('pv_' + el.dataset.k);
      pv.style.backgroundImage = `url('${data}')`; pv.textContent = '';
    } catch (e) { toast('تعذر قراءة الصورة'); }
  };

  return { MONTHS, DAYS, esc, iso, parse, diffDays, fmtDate, fmtShort, money, toast, sheet, close, form, compress };
})();
